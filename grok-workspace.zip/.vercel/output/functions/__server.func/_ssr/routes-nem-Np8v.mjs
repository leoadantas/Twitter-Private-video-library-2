import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as AddVideoForm, c as useLibrary, d as useServerFn, i as Route$2, s as allVideos, u as resolveVideo } from "./router-DSBZPn7q.mjs";
import { t as LibraryView } from "./library-view-kYs4pwwR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-nem-Np8v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	const { add } = Route$2.useSearch();
	const navigate = useNavigate();
	const resolve = useServerFn(resolveVideo);
	const videos = useLibrary((state) => allVideos(state.videos));
	const saveTweet = useLibrary((state) => state.saveTweet);
	const started = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!add || started.current) return;
		started.current = true;
		(async () => {
			const result = await resolve({ data: { ref: add } });
			if (!result.ok) {
				toast.error(result.message);
				await navigate({
					to: "/",
					search: {},
					replace: true
				});
				return;
			}
			saveTweet(result.tweet, "inbox");
			await navigate({
				to: "/watch/$videoId",
				params: { videoId: result.tweet.id },
				search: { list: "inbox" },
				replace: true
			});
		})();
	}, [
		add,
		navigate,
		resolve,
		saveTweet
	]);
	if (add) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "Salvando vídeo…"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Buscando o post no X."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryView, {
		title: "Todos os vídeos",
		videos,
		empty: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl py-6 sm:py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-wide text-accent",
					children: "Biblioteca pessoal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-extrabold tracking-tight text-balance sm:text-4xl",
					children: "Os vídeos do X que você não pode ver agora."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-pretty text-muted",
					children: "O app do X não deixa instalar outra tela lá dentro. Cole o link aqui, separe em pastas e assista quando der — com fila, progresso e só o que você escolheu."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 rounded-2xl border border-line bg-surface p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddVideoForm, { showSample: true })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid gap-3 sm:grid-cols-3",
					children: [
						["1", "Abra o vídeo no X"],
						["2", "Compartilhar e copiar o link"],
						["3", "Cole aqui e escolha a pasta"]
					].map(([step, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-line bg-surface px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold text-accent",
							children: step
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-pretty",
							children: label
						})]
					}, step))
				})
			]
		})
	});
}
//#endregion
export { HomePage as component };
