import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as extractStatusId } from "./x-url-CAO-RKT4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resolve-video-DWdFOCVe.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function isMp4(url, container) {
	if (container === "m3u8" || url.includes(".m3u8")) return false;
	return container === "mp4" || url.includes(".mp4");
}
function labelFor(url, bitrate) {
	const size = url.match(/\/(\d+)x(\d+)\//);
	if (size) return `${Number(size[2])}p`;
	if (bitrate <= 3e5) return "270p";
	if (bitrate <= 9e5) return "360p";
	if (bitrate <= 25e5) return "720p";
	if (bitrate <= 8e6) return "1080p";
	return "4K";
}
function dedupeSources(list) {
	const map = /* @__PURE__ */ new Map();
	for (const source of list) {
		const prev = map.get(source.label);
		if (!prev || source.bitrate > prev.bitrate) map.set(source.label, source);
	}
	return [...map.values()].sort((a, b) => a.bitrate - b.bitrate);
}
function clipsFrom(media) {
	const clips = [];
	for (const item of media?.all ?? []) {
		const formats = (item.formats ?? []).filter((format) => format.url && isMp4(format.url, format.container));
		if (!formats.length && item.url && isMp4(item.url)) formats.push({
			url: item.url,
			bitrate: 0,
			container: "mp4"
		});
		if (!formats.length) continue;
		const sources = dedupeSources(formats.map((format) => ({
			url: format.url,
			bitrate: format.bitrate ?? 0,
			label: labelFor(format.url, format.bitrate ?? 0)
		})));
		clips.push({
			thumbnailUrl: item.thumbnail_url || "",
			durationSec: item.duration || 0,
			sources
		});
		if (clips.length >= 4) break;
	}
	return clips;
}
var resolveVideo_createServerFn_handler = createServerRpc({
	id: "a4e687a33c291aa25018076e1cef669cd48693ae98972e5446c142679649eab5",
	name: "resolveVideo",
	filename: "src/lib/resolve-video.ts"
}, (opts) => resolveVideo.__executeServer(opts));
var resolveVideo = createServerFn({ method: "POST" }).validator((input) => {
	const ref = typeof input?.ref === "string" ? input.ref.trim() : "";
	if (!ref || ref.length > 500) return { ref: "" };
	return { ref };
}).handler(resolveVideo_createServerFn_handler, async ({ data }) => {
	const id = extractStatusId(data.ref);
	if (!id) return {
		ok: false,
		message: "Isso não parece um link de post do X."
	};
	let response;
	try {
		response = await fetch(`https://api.fxtwitter.com/status/${id}`, {
			signal: AbortSignal.timeout(12e3),
			headers: { accept: "application/json" }
		});
	} catch {
		return {
			ok: false,
			message: "Sem conexão com o X agora. Tenta de novo."
		};
	}
	let payload;
	try {
		payload = await response.json();
	} catch {
		return {
			ok: false,
			message: "O X não devolveu esse post. Tenta de novo."
		};
	}
	if (!response.ok || payload.code === 404 || !payload.tweet) return {
		ok: false,
		message: "Não achei esse post. Ele pode ser privado ou ter sido apagado."
	};
	const tweet = payload.tweet;
	const clips = clipsFrom(tweet.media);
	if (!clips.length) return {
		ok: false,
		message: "Esse post não tem vídeo. Abre um vídeo no X, toca em compartilhar e copia o link."
	};
	const handle = tweet.author?.screen_name || "x";
	return {
		ok: true,
		tweet: {
			id,
			url: tweet.url || `https://x.com/${handle}/status/${id}`,
			text: (tweet.text || "").replace(/\s+/g, " ").trim().slice(0, 2e3),
			authorName: tweet.author?.name || handle,
			authorHandle: handle,
			avatarUrl: tweet.author?.avatar_url || "",
			clips
		}
	};
});
//#endregion
export { resolveVideo_createServerFn_handler };
