import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ExternalLink, d as Pause, f as Minimize, l as Play, m as Maximize, n as VolumeX, o as SkipForward, r as Volume2, y as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useLibrary, l as videosIn, n as Route, o as cn, s as allVideos } from "./router-DSBZPn7q.mjs";
import { n as formatClock, o as videoTitle } from "./x-url-CAO-RKT4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._videoId-DLptkkk3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RATES = [
	1,
	1.25,
	1.5,
	2
];
function pickSource(sources) {
	return sources.find((source) => source.label === "720p") ?? sources.find((source) => source.bitrate >= 8e5 && source.bitrate <= 28e5) ?? sources[Math.min(sources.length - 1, Math.floor(sources.length / 2))];
}
function typingTarget(target) {
	if (!(target instanceof HTMLElement)) return false;
	return Boolean(target.closest("input, textarea, select, [contenteditable='true']"));
}
function Player({ videoKey, sources, poster, initialTime, title, onProgress, onComplete, nextTitle, onNext }) {
	const videoRef = (0, import_react.useRef)(null);
	const frameRef = (0, import_react.useRef)(null);
	const progressRef = (0, import_react.useRef)(onProgress);
	const completeRef = (0, import_react.useRef)(onComplete);
	const nextRef = (0, import_react.useRef)(onNext);
	progressRef.current = onProgress;
	completeRef.current = onComplete;
	nextRef.current = onNext;
	const volume = useLibrary((state) => state.volume);
	const setVolume = useLibrary((state) => state.setVolume);
	const autoplay = useLibrary((state) => state.autoplay);
	const setAutoplay = useLibrary((state) => state.setAutoplay);
	const chosen = pickSource(sources);
	const [source, setSource] = (0, import_react.useState)(chosen);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [time, setTime] = (0, import_react.useState)(0);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [ended, setEnded] = (0, import_react.useState)(false);
	const [canceled, setCanceled] = (0, import_react.useState)(false);
	const [count, setCount] = (0, import_react.useState)(5);
	const [fullscreen, setFullscreen] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [rate, setRate] = (0, import_react.useState)(1);
	const lastSave = (0, import_react.useRef)(0);
	const didInit = (0, import_react.useRef)(false);
	const pendingSeek = (0, import_react.useRef)(null);
	const resumePlay = (0, import_react.useRef)(false);
	const sourceKey = sources.map((item) => `${item.label}:${item.url}`).join("|");
	(0, import_react.useEffect)(() => {
		setSource(pickSource(sources));
		setEnded(false);
		setCanceled(false);
		setFailed(false);
		setPlaying(false);
		setTime(0);
		didInit.current = false;
	}, [videoKey, sourceKey]);
	(0, import_react.useEffect)(() => {
		const element = videoRef.current;
		if (element) element.volume = muted ? 0 : volume;
	}, [volume, muted]);
	(0, import_react.useEffect)(() => {
		const onChange = () => setFullscreen(document.fullscreenElement === frameRef.current);
		document.addEventListener("fullscreenchange", onChange);
		return () => document.removeEventListener("fullscreenchange", onChange);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ended || canceled || !autoplay || !onNext) return;
		setCount(5);
		let left = 5;
		const timer = window.setInterval(() => {
			left -= 1;
			setCount(left);
			if (left <= 0) {
				window.clearInterval(timer);
				nextRef.current?.();
			}
		}, 1e3);
		return () => window.clearInterval(timer);
	}, [
		ended,
		canceled,
		autoplay,
		onNext,
		videoKey
	]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (typingTarget(event.target)) return;
			const element = videoRef.current;
			if (!element) return;
			if (event.code === "Space" || event.key === "k") {
				event.preventDefault();
				toggle();
			} else if (event.key === "ArrowRight") {
				event.preventDefault();
				seek(element.currentTime + 5);
			} else if (event.key === "ArrowLeft") {
				event.preventDefault();
				seek(element.currentTime - 5);
			} else if (event.key === "f") {
				event.preventDefault();
				toggleFullscreen();
			} else if (event.key === "m") {
				event.preventDefault();
				setMuted((value) => !value);
			} else if (event.key === "n" && nextRef.current) {
				event.preventDefault();
				nextRef.current();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function seek(next) {
		const element = videoRef.current;
		if (!element) return;
		const max = Number.isFinite(element.duration) ? element.duration : next;
		const value = Math.min(Math.max(0, next), max);
		element.currentTime = value;
		setTime(value);
		setEnded(false);
		lastSave.current = performance.now();
		progressRef.current(value, element.duration || 0);
	}
	function toggle() {
		const element = videoRef.current;
		if (!element) return;
		if (element.paused) {
			setEnded(false);
			element.play();
		} else element.pause();
	}
	async function toggleFullscreen() {
		const frame = frameRef.current;
		if (!frame) return;
		if (document.fullscreenElement === frame) await document.exitFullscreen();
		else await frame.requestFullscreen();
	}
	function changeSource(next) {
		const element = videoRef.current;
		pendingSeek.current = element?.currentTime ?? 0;
		resumePlay.current = Boolean(element && !element.paused);
		didInit.current = true;
		setSource(next);
	}
	const percent = duration > 0 ? Math.min(100, time / duration * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: frameRef,
		className: "overflow-hidden rounded-xl border border-line bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-video bg-bg",
				onDoubleClick: () => void toggleFullscreen(),
				children: [
					source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						className: "size-full bg-bg object-contain",
						poster: poster || void 0,
						playsInline: true,
						preload: "metadata",
						src: source.url,
						onPlay: () => setPlaying(true),
						onPause: () => setPlaying(false),
						onLoadedMetadata: (event) => {
							const element = event.currentTarget;
							element.playbackRate = rate;
							element.volume = muted ? 0 : volume;
							setDuration(element.duration || 0);
							if (pendingSeek.current != null) {
								element.currentTime = pendingSeek.current;
								pendingSeek.current = null;
								if (resumePlay.current) element.play();
								return;
							}
							if (!didInit.current) {
								didInit.current = true;
								if (initialTime > 1 && initialTime < (element.duration || Infinity) - 1) {
									element.currentTime = initialTime;
									setTime(initialTime);
								}
							}
						},
						onTimeUpdate: (event) => {
							const element = event.currentTarget;
							setTime(element.currentTime);
							if (Number.isFinite(element.duration)) setDuration(element.duration);
							const now = performance.now();
							if (now - lastSave.current > 2e3) {
								lastSave.current = now;
								progressRef.current(element.currentTime, element.duration || 0);
							}
						},
						onEnded: () => {
							const element = videoRef.current;
							setEnded(true);
							setPlaying(false);
							if (element) progressRef.current(element.duration || element.currentTime, element.duration || 0);
							completeRef.current();
						},
						onError: () => setFailed(true),
						onClick: toggle
					}, source.url) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-full place-items-center px-6 text-center text-sm text-muted",
						children: "Não achei um arquivo de vídeo reproduzível nesse post."
					}),
					failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center bg-bg/80 px-6 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-sm text-sm text-pretty",
							children: "O X não entregou esse arquivo agora. Ele pode ter expirado ou o post saiu do ar."
						})
					}) : null,
					!playing && !ended && source && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Reproduzir",
						className: "tap absolute inset-0 grid place-items-center",
						onClick: toggle,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-16 place-items-center rounded-full bg-bg/75 text-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-7 fill-current" })
						})
					}) : null,
					ended ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 grid place-items-center gap-3 bg-bg/80 px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-semibold text-balance",
								children: "Acabou"
							}),
							nextTitle && !canceled && autoplay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									"Próximo em ",
									count,
									"s · ",
									nextTitle
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "tap min-h-11 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink",
										onClick: () => {
											setEnded(false);
											setCanceled(false);
											seek(0);
											videoRef.current?.play();
										},
										children: "Assistir de novo"
									}),
									onNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "tap min-h-11 rounded-lg border border-line bg-surface px-4 text-sm font-semibold",
										onClick: () => onNext(),
										children: "Próximo"
									}) : null,
									onNext && autoplay && !canceled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 px-3 text-sm text-muted",
										onClick: () => setCanceled(true),
										children: "Cancelar"
									}) : null
								]
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/80 to-transparent px-3 pt-10 pb-2", ended && "hidden"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							role: "slider",
							tabIndex: 0,
							"aria-label": "Posição do vídeo",
							"aria-valuemin": 0,
							"aria-valuemax": Math.round(duration || 0),
							"aria-valuenow": Math.round(time),
							className: "group relative flex h-6 cursor-pointer touch-none items-center",
							onPointerDown: (event) => {
								const rect = event.currentTarget.getBoundingClientRect();
								seek((event.clientX - rect.left) / rect.width * (duration || 0));
								event.currentTarget.setPointerCapture(event.pointerId);
							},
							onPointerMove: (event) => {
								if (event.buttons !== 1) return;
								const rect = event.currentTarget.getBoundingClientRect();
								seek((event.clientX - rect.left) / rect.width * (duration || 0));
							},
							onKeyDown: (event) => {
								if (event.key === "ArrowRight") seek(time + 5);
								if (event.key === "ArrowLeft") seek(time - 5);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative h-1 w-full rounded-full bg-fg/25 group-hover:h-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute inset-y-0 left-0 rounded-full bg-accent",
									style: { width: `${percent}%` }
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center gap-1 text-fg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap grid size-11 place-items-center",
									"aria-label": playing ? "Pausar" : "Reproduzir",
									onClick: toggle,
									children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current" })
								}),
								onNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap grid size-11 place-items-center",
									"aria-label": "Próximo",
									onClick: onNext,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-5" })
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-1 text-xs tabular-nums text-fg/90",
									children: [
										formatClock(time),
										" / ",
										formatClock(duration)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap grid size-11 place-items-center",
									"aria-label": muted || volume === 0 ? "Ativar som" : "Silenciar",
									onClick: () => setMuted((value) => !value),
									children: muted || volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									"aria-label": "Volume",
									type: "range",
									min: 0,
									max: 1,
									step: .05,
									value: muted ? 0 : volume,
									onChange: (event) => {
										const next = Number(event.target.value);
										setMuted(false);
										setVolume(next);
									},
									className: "hidden w-20 accent-accent sm:block"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "sr-only",
									htmlFor: `rate-${videoKey}`,
									children: "Velocidade"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: `rate-${videoKey}`,
									"aria-label": "Velocidade",
									value: rate,
									onChange: (event) => {
										const next = Number(event.target.value);
										setRate(next);
										if (videoRef.current) videoRef.current.playbackRate = next;
									},
									className: "h-9 rounded-md bg-transparent px-1 text-xs font-semibold",
									children: RATES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: item,
										className: "bg-surface text-fg",
										children: [item, "×"]
									}, item))
								}),
								sources.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									"aria-label": "Qualidade",
									value: source?.label ?? "",
									onChange: (event) => {
										const next = sources.find((item) => item.label === event.target.value);
										if (next) changeSource(next);
									},
									className: "h-9 max-w-20 rounded-md bg-transparent px-1 text-xs font-semibold",
									children: sources.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item.label,
										className: "bg-surface text-fg",
										children: item.label
									}, item.label))
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "tap grid size-11 place-items-center",
									"aria-label": "Tela cheia",
									onClick: () => void toggleFullscreen(),
									children: fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-5" })
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex items-center justify-between gap-3 px-3 py-2 text-xs text-muted", "max-sm:hidden"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Espaço reproduz · setas pulam 5s · F tela cheia · N próximo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-medium text-fg",
					onClick: () => setAutoplay(!autoplay),
					children: autoplay ? "Autoplay ligado" : "Autoplay desligado"
				})]
			})
		]
	});
}
function WatchPage() {
	const { videoId } = Route.useParams();
	const { list } = Route.useSearch();
	const fresh = Route.useLoaderData();
	const navigate = useNavigate();
	const saved = useLibrary((state) => state.videos[videoId]);
	const playlists = useLibrary((state) => state.playlists);
	const videos = useLibrary((state) => state.videos);
	const refreshMeta = useLibrary((state) => state.refreshMeta);
	const saveTweet = useLibrary((state) => state.saveTweet);
	const setProgress = useLibrary((state) => state.setProgress);
	const setCompleted = useLibrary((state) => state.setCompleted);
	const setClipIndex = useLibrary((state) => state.setClipIndex);
	const removeFromLibrary = useLibrary((state) => state.removeFromLibrary);
	const restore = useLibrary((state) => state.restore);
	const autoplay = useLibrary((state) => state.autoplay);
	const setAutoplay = useLibrary((state) => state.setAutoplay);
	const [clip, setClip] = (0, import_react.useState)(saved?.clipIndex ?? 0);
	const [resumeFrom] = (0, import_react.useState)(() => saved && !saved.completed && saved.positionSec > 3 ? saved.positionSec : 0);
	(0, import_react.useEffect)(() => {
		if (fresh.ok) refreshMeta(fresh.tweet);
	}, [fresh, refreshMeta]);
	const tweet = fresh.ok ? fresh.tweet : saved;
	if (!tweet) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-lg py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "Não deu para abrir"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-muted",
				children: fresh.ok ? "Vídeo indisponível." : fresh.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				search: {},
				className: "mt-4 inline-flex min-h-11 items-center font-semibold text-accent",
				children: "Voltar para a biblioteca"
			})
		]
	});
	const clips = fresh.ok ? fresh.tweet.clips : saved?.clips ?? [];
	const active = clips[clip] ?? clips[0];
	const title = videoTitle(tweet);
	const queue = queueAfter(videos, playlists, videoId, list);
	const next = queue[0];
	const playlistName = playlists.find((playlist) => playlist.id === list)?.name;
	function goNext(target = next) {
		if (!target) return;
		navigate({
			to: "/watch/$videoId",
			params: { videoId: target.id },
			search: { list }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-6 lg:grid-cols-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 lg:col-span-3",
			children: [
				!fresh.ok && saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 rounded-lg border border-line bg-surface px-3 py-2 text-sm text-muted",
					children: "Não atualizei o link com o X. Tocando a cópia que já estava salva."
				}) : null,
				active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
					videoKey: `${tweet.id}:${clip}`,
					sources: active.sources,
					poster: active.thumbnailUrl,
					initialTime: saved && !saved.completed && (saved.clipIndex ?? 0) === clip ? saved.positionSec : 0,
					title,
					onProgress: (position, duration) => {
						if (saved) setProgress(saved.id, position, duration);
					},
					onComplete: () => {
						if (saved) setCompleted(saved.id, true);
					},
					nextTitle: next ? videoTitle(next) : void 0,
					onNext: next ? () => goNext() : void 0
				}, `${tweet.id}:${clip}`) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-xl font-bold text-balance sm:text-2xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `https://x.com/${tweet.authorHandle}`,
							target: "_blank",
							rel: "noreferrer",
							className: "flex min-w-0 items-center gap-3",
							children: [tweet.avatarUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: tweet.avatarUrl,
								alt: "",
								className: "size-10 rounded-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 place-items-center rounded-full bg-raised text-sm font-bold",
								children: tweet.authorName.slice(0, 1)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-semibold",
									children: tweet.authorName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-sm text-muted",
									children: ["@", tweet.authorHandle]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
						saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "tap inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold",
							onClick: () => setCompleted(saved.id, !saved.completed),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-accent" }), saved.completed ? "Visto" : "Marcar visto"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap min-h-11 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink",
							onClick: () => {
								if (!fresh.ok) return;
								saveTweet(fresh.tweet, list || "inbox");
								toast("Salvo para depois");
							},
							children: "Salvar para depois"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: tweet.url,
							target: "_blank",
							rel: "noreferrer",
							className: "tap inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold",
							children: ["Abrir no X", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
						}),
						saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 px-2 text-sm text-muted",
							onClick: () => {
								const snapshot = removeFromLibrary(saved.id);
								if (!snapshot) return;
								toast("Removido da biblioteca", { action: {
									label: "Desfazer",
									onClick: () => restore(snapshot)
								} });
								navigate({
									to: "/",
									search: {}
								});
							},
							children: "Remover"
						}) : null
					]
				}),
				resumeFrom > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Continua de ",
						formatClock(resumeFrom),
						"."
					]
				}) : null,
				clips.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: clips.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setClip(index);
							if (saved) setClipIndex(saved.id, index);
						},
						className: index === clip ? "min-h-11 rounded-lg bg-accent px-3 text-sm font-semibold text-accent-ink" : "tap min-h-11 rounded-lg border border-line px-3 text-sm",
						children: [
							"Vídeo ",
							index + 1,
							item.durationSec > 0 ? ` · ${formatClock(item.durationSec)}` : ""
						]
					}, item.sources[0]?.url ?? index))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-pretty text-muted sm:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "font-medium text-fg",
						onClick: () => setAutoplay(!autoplay),
						children: autoplay ? "Autoplay ligado" : "Autoplay desligado"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-xl border border-line bg-surface p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "px-1 text-sm font-semibold",
				children: playlistName ? `A seguir em ${playlistName}` : "A seguir"
			}), queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 py-4 text-sm text-muted",
				children: "Fim da fila."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 grid gap-2",
				children: queue.map((item) => {
					const itemClip = item.clips[item.clipIndex] ?? item.clips[0];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => goNext(item),
						className: "flex w-full gap-3 rounded-lg p-1 text-left hover:bg-raised",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative block w-28 shrink-0 overflow-hidden rounded-md bg-raised",
							children: [itemClip?.thumbnailUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: itemClip.thumbnailUrl,
								alt: "",
								className: "aspect-video w-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block aspect-video" }), itemClip && itemClip.durationSec > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute right-1 bottom-1 rounded bg-bg/80 px-1 text-xs tabular-nums",
								children: formatClock(itemClip.durationSec)
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "line-clamp-2 text-sm font-medium text-balance",
								children: videoTitle(item)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block truncate text-xs text-muted",
								children: ["@", item.authorHandle]
							})]
						})]
					}) }, item.id);
				})
			})]
		})]
	});
}
function queueAfter(videos, playlists, currentId, list) {
	if (list) {
		const playlist = playlists.find((item) => item.id === list);
		const ordered = videosIn(playlist, videos);
		const index = ordered.findIndex((video) => video.id === currentId);
		return index >= 0 ? ordered.slice(index + 1) : ordered.filter((video) => video.id !== currentId);
	}
	return allVideos(videos).filter((video) => video.id !== currentId && !video.completed);
}
//#endregion
export { WatchPage as component };
