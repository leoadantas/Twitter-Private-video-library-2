import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { G as isRedirect, S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as Plus, g as FolderPlus, h as ListVideo, i as TriangleAlert, l as Play, p as Menu, s as Search, t as X } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resolve-video-DNC4D2hp.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var resolveVideo = createServerFn({ method: "POST" }).validator((input) => {
	const ref = typeof input?.ref === "string" ? input.ref.trim() : "";
	if (!ref || ref.length > 500) return { ref: "" };
	return { ref };
}).handler(createSsrRpc("a4e687a33c291aa25018076e1cef669cd48693ae98972e5446c142679649eab5"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DSBZPn7q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
var INBOX_ID = "inbox";
var SAMPLE_REF = "https://x.com/NASAAdmin/status/2114425731832775042";
function inbox() {
	return {
		id: INBOX_ID,
		name: "Assistir depois",
		videoIds: [],
		createdAt: 0
	};
}
function withInbox(playlists) {
	if (playlists.some((playlist) => playlist.id === "inbox")) return playlists;
	return [inbox(), ...playlists];
}
function cleanName(name) {
	const trimmed = name.trim().replace(/\s+/g, " ");
	if (!trimmed) return null;
	return trimmed.slice(0, 40);
}
function membershipsOf(playlists, videoId) {
	return playlists.filter((playlist) => playlist.videoIds.includes(videoId)).map((playlist) => playlist.id);
}
var useLibrary = create()(persist((set, get) => ({
	videos: {},
	playlists: [inbox()],
	autoplay: true,
	volume: 1,
	hydrated: false,
	query: "",
	composerOpen: false,
	composerPlaylistId: INBOX_ID,
	folderOpen: false,
	setQuery: (query) => set({ query }),
	openComposer: (playlistId) => set({
		composerOpen: true,
		composerPlaylistId: playlistId || "inbox"
	}),
	closeComposer: () => set({ composerOpen: false }),
	setFolderOpen: (folderOpen) => set({ folderOpen }),
	saveTweet: (tweet, playlistId) => {
		const target = get().playlists.some((playlist) => playlist.id === playlistId) ? playlistId : INBOX_ID;
		const already = get().videos[tweet.id] ? get().playlists.some((playlist) => playlist.id === target && playlist.videoIds.includes(tweet.id)) : false;
		set((state) => {
			const previous = state.videos[tweet.id];
			const saved = {
				...tweet,
				clipIndex: previous?.clipIndex ?? 0,
				addedAt: previous?.addedAt ?? Date.now(),
				positionSec: previous?.positionSec ?? 0,
				completed: previous?.completed ?? false
			};
			if (saved.clipIndex >= saved.clips.length) saved.clipIndex = 0;
			return {
				videos: {
					...state.videos,
					[tweet.id]: saved
				},
				playlists: state.playlists.map((playlist) => {
					if (playlist.id !== target || playlist.videoIds.includes(tweet.id)) return playlist;
					return {
						...playlist,
						videoIds: [tweet.id, ...playlist.videoIds]
					};
				})
			};
		});
		return already ? "exists" : "added";
	},
	createPlaylist: (name) => {
		const clean = cleanName(name);
		if (!clean) return null;
		const id = `pl_${crypto.randomUUID()}`;
		set((state) => ({ playlists: [...state.playlists, {
			id,
			name: clean,
			videoIds: [],
			createdAt: Date.now()
		}] }));
		return id;
	},
	renamePlaylist: (id, name) => {
		const clean = cleanName(name);
		if (!clean) return;
		set((state) => ({ playlists: state.playlists.map((playlist) => playlist.id === id ? {
			...playlist,
			name: clean
		} : playlist) }));
	},
	deletePlaylist: (id) => {
		if (id === "inbox") return;
		set((state) => ({ playlists: state.playlists.filter((playlist) => playlist.id !== id) }));
	},
	toggleMembership: (videoId, playlistId) => {
		if (!get().videos[videoId]) return;
		set((state) => ({ playlists: state.playlists.map((playlist) => {
			if (playlist.id !== playlistId) return playlist;
			const has = playlist.videoIds.includes(videoId);
			return {
				...playlist,
				videoIds: has ? playlist.videoIds.filter((item) => item !== videoId) : [videoId, ...playlist.videoIds]
			};
		}) }));
	},
	removeFromPlaylist: (videoId, playlistId) => {
		set((state) => ({ playlists: state.playlists.map((playlist) => playlist.id === playlistId ? {
			...playlist,
			videoIds: playlist.videoIds.filter((item) => item !== videoId)
		} : playlist) }));
	},
	removeFromLibrary: (videoId) => {
		const video = get().videos[videoId];
		if (!video) return null;
		const snapshot = {
			video,
			memberships: membershipsOf(get().playlists, videoId)
		};
		set((state) => {
			const videos = { ...state.videos };
			delete videos[videoId];
			return {
				videos,
				playlists: state.playlists.map((playlist) => ({
					...playlist,
					videoIds: playlist.videoIds.filter((item) => item !== videoId)
				}))
			};
		});
		return snapshot;
	},
	restore: (snapshot) => {
		set((state) => ({
			videos: {
				...state.videos,
				[snapshot.video.id]: snapshot.video
			},
			playlists: state.playlists.map((playlist) => {
				if (!snapshot.memberships.includes(playlist.id) || playlist.videoIds.includes(snapshot.video.id)) return playlist;
				return {
					...playlist,
					videoIds: [snapshot.video.id, ...playlist.videoIds]
				};
			})
		}));
	},
	setProgress: (id, positionSec, durationSec) => {
		set((state) => {
			const video = state.videos[id];
			if (!video) return state;
			const completed = video.completed || durationSec > 0 && positionSec / durationSec >= .9;
			return { videos: {
				...state.videos,
				[id]: {
					...video,
					positionSec,
					completed
				}
			} };
		});
	},
	setCompleted: (id, completed) => {
		set((state) => {
			const video = state.videos[id];
			if (!video) return state;
			return { videos: {
				...state.videos,
				[id]: {
					...video,
					completed,
					positionSec: completed ? video.positionSec : 0
				}
			} };
		});
	},
	setClipIndex: (id, clipIndex) => {
		set((state) => {
			const video = state.videos[id];
			if (!video || !video.clips[clipIndex]) return state;
			return { videos: {
				...state.videos,
				[id]: {
					...video,
					clipIndex,
					positionSec: 0
				}
			} };
		});
	},
	refreshMeta: (tweet) => {
		set((state) => {
			const video = state.videos[tweet.id];
			if (!video) return state;
			const clipIndex = video.clipIndex < tweet.clips.length ? video.clipIndex : 0;
			return { videos: {
				...state.videos,
				[tweet.id]: {
					...video,
					...tweet,
					clipIndex
				}
			} };
		});
	},
	setAutoplay: (autoplay) => set({ autoplay }),
	setVolume: (volume) => set({ volume: Math.min(1, Math.max(0, volume)) })
}), {
	name: "depois-library-v1",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		videos: state.videos,
		playlists: state.playlists,
		autoplay: state.autoplay,
		volume: state.volume
	}),
	merge: (persisted, current) => {
		const data = persisted ?? {};
		const playlists = Array.isArray(data.playlists) ? data.playlists.filter((playlist) => playlist && typeof playlist.id === "string") : [];
		const videos = {};
		if (data.videos && typeof data.videos === "object") {
			for (const video of Object.values(data.videos)) if (video && typeof video.id === "string" && Array.isArray(video.clips) && video.clips.length > 0) videos[video.id] = video;
		}
		return {
			...current,
			videos,
			playlists: withInbox(playlists).map((playlist) => ({
				...playlist,
				videoIds: (playlist.videoIds ?? []).filter((id) => typeof id === "string" && videos[id])
			})),
			autoplay: typeof data.autoplay === "boolean" ? data.autoplay : true,
			volume: typeof data.volume === "number" ? data.volume : 1,
			hydrated: true
		};
	}
}));
function videosIn(playlist, videos) {
	if (!playlist) return [];
	return playlist.videoIds.map((id) => videos[id]).filter((video) => Boolean(video));
}
function allVideos(videos) {
	return Object.values(videos).sort((a, b) => b.addedAt - a.addedAt);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function AddVideoForm({ playlistId, onDone, showSample }) {
	const resolve = useServerFn(resolveVideo);
	const navigate = useNavigate();
	const playlists = useLibrary((state) => state.playlists);
	const saveTweet = useLibrary((state) => state.saveTweet);
	const createPlaylist = useLibrary((state) => state.createPlaylist);
	const [ref, setRef] = (0, import_react.useState)("");
	const [folderId, setFolderId] = (0, import_react.useState)(playlistId || "inbox");
	const [folderName, setFolderName] = (0, import_react.useState)("");
	const [makingFolder, setMakingFolder] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save(value, target) {
		setBusy(true);
		setError(null);
		const result = await resolve({ data: { ref: value } });
		if (!result.ok) {
			setError(result.message);
			setBusy(false);
			return;
		}
		const status = saveTweet(result.tweet, target);
		toast(status === "exists" ? "Esse vídeo já estava na pasta" : "Vídeo salvo");
		setRef("");
		setBusy(false);
		onDone?.();
		await navigate({
			to: "/watch/$videoId",
			params: { videoId: result.tweet.id },
			search: { list: target }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			if (!busy && ref.trim()) save(ref, folderId);
		},
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-2 text-sm font-medium",
				children: ["Link do post", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: ref,
					onChange: (event) => setRef(event.target.value),
					placeholder: "https://x.com/alguem/status/…",
					inputMode: "url",
					autoComplete: "off",
					spellCheck: false,
					className: "min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-base font-normal text-fg outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-[1fr_auto] sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-2 text-sm font-medium",
					children: ["Pasta", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: folderId,
						onChange: (event) => setFolderId(event.target.value),
						className: "min-h-11 rounded-lg border border-line bg-bg px-3 text-base font-normal text-fg",
						children: playlists.map((playlist) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: playlist.id,
							children: playlist.name
						}, playlist.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy || !ref.trim(),
					className: "tap min-h-11 rounded-lg bg-accent px-4 font-semibold text-accent-ink disabled:opacity-50",
					children: busy ? "Buscando…" : "Salvar"
				})]
			}),
			makingFolder ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: folderName,
					onChange: (event) => setFolderName(event.target.value),
					placeholder: "Nome da pasta",
					className: "min-h-11 min-w-0 flex-1 rounded-lg border border-line bg-bg px-3 text-base"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap min-h-11 rounded-lg border border-line px-3 text-sm font-semibold",
					onClick: () => {
						const id = createPlaylist(folderName);
						if (!id) {
							setError("Dá um nome para a pasta.");
							return;
						}
						setFolderId(id);
						setFolderName("");
						setMakingFolder(false);
					},
					children: "Criar"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "w-fit text-sm font-medium text-accent",
				onClick: () => setMakingFolder(true),
				children: "Nova pasta"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-accent",
				children: error
			}) : null,
			showSample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				className: cn("w-fit text-sm text-muted underline-offset-4 hover:text-fg hover:underline", busy && "opacity-50"),
				onClick: () => void save(SAMPLE_REF, folderId),
				children: "Ver um exemplo com um vídeo público"
			}) : null
		]
	});
}
function typingTarget(target) {
	if (!(target instanceof HTMLElement)) return false;
	return Boolean(target.closest("input, textarea, select, [contenteditable='true']"));
}
function bookmarklet(origin) {
	return `javascript:${`(function(){var m=location.href.match(/status(?:es)?\\/(\\d+)/);if(!m){alert("Abra um post do X primeiro.");return;}window.open(${JSON.stringify(origin)}+"/?add="+m[1]);})();`}`;
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const hydrated = useLibrary((state) => state.hydrated);
	const playlists = useLibrary((state) => state.playlists);
	const videoCount = useLibrary((state) => Object.keys(state.videos).length);
	const query = useLibrary((state) => state.query);
	const setQuery = useLibrary((state) => state.setQuery);
	const composerOpen = useLibrary((state) => state.composerOpen);
	const closeComposer = useLibrary((state) => state.closeComposer);
	const openComposer = useLibrary((state) => state.openComposer);
	const composerPlaylistId = useLibrary((state) => state.composerPlaylistId);
	const folderOpen = useLibrary((state) => state.folderOpen);
	const setFolderOpen = useLibrary((state) => state.setFolderOpen);
	const createPlaylist = useLibrary((state) => state.createPlaylist);
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	const [folderName, setFolderName] = (0, import_react.useState)("");
	const [folderError, setFolderError] = (0, import_react.useState)(null);
	const [origin, setOrigin] = (0, import_react.useState)("");
	const searchRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const pending = useLibrary.persist.rehydrate();
		Promise.resolve(pending).finally(() => {
			useLibrary.setState({ hydrated: true });
		});
		setOrigin(window.location.origin);
	}, []);
	(0, import_react.useEffect)(() => {
		setNavOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "/" && !typingTarget(event.target)) {
				event.preventDefault();
				searchRef.current?.focus();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const nav = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-3 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
				to: "/",
				active: pathname === "/",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListVideo, { className: "size-4" }),
				label: "Todos os vídeos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 mb-1 flex items-center justify-between px-3 text-xs font-semibold tracking-wide text-muted",
				children: ["Pastas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap grid size-11 place-items-center rounded-md text-muted hover:bg-raised hover:text-fg",
					"aria-label": "Nova pasta",
					onClick: () => {
						setFolderError(null);
						setFolderOpen(true);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, { className: "size-4" })
				})]
			}),
			playlists.map((playlist) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
				to: "/p/$playlistId",
				params: { playlistId: playlist.id },
				active: pathname === `/p/${playlist.id}`,
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-accent" }),
				label: playlist.name,
				count: playlist.videoIds.length
			}, playlist.id))
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed inset-x-0 top-0 z-50 h-0.5 bg-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-line bg-surface pt-0.5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						search: { add: void 0 },
						className: "flex items-center gap-3 px-4 py-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
					}),
					nav,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarFoot, { origin })
				]
			}),
			navOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Fechar menu",
					className: "absolute inset-0 bg-bg/70",
					onClick: () => setNavOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-y-0 left-0 flex w-72 flex-col border-r border-line bg-surface pt-0.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Fechar",
								className: "tap grid size-11 place-items-center",
								onClick: () => setNavOpen(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						nav,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarFoot, { origin })
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 md:pl-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 border-b border-line bg-bg/90 px-3 py-2 backdrop-blur-md md:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "tap grid size-11 place-items-center rounded-lg md:hidden",
								"aria-label": "Abrir menu",
								onClick: () => setNavOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								search: { add: void 0 },
								className: "pr-2 font-extrabold md:hidden",
								children: "Depois"
							})]
						}),
						videoCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Buscar na biblioteca"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: searchRef,
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Buscar na biblioteca",
									className: "min-h-11 w-full rounded-lg border border-line bg-surface pr-3 pl-9 text-sm outline-none placeholder:text-muted"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "tap inline-flex min-h-11 items-center gap-2 rounded-lg bg-accent px-3 font-semibold text-accent-ink",
							onClick: () => openComposer(pathname.startsWith("/p/") ? pathname.split("/")[2] : INBOX_ID),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Adicionar"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-7xl px-4 py-6 md:px-6",
					children: hydrated ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-sm text-muted",
						children: "Abrindo sua biblioteca…"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: composerOpen,
				onOpenChange: (open) => open ? openComposer(composerPlaylistId) : closeComposer(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed inset-x-4 top-1/2 z-50 mx-auto max-w-lg -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-lg font-bold",
							children: "Adicionar vídeo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-1 mb-4 text-sm text-pretty text-muted",
							children: "No X, abra o vídeo, toque em compartilhar e copie o link do post."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddVideoForm, {
							playlistId: composerPlaylistId,
							onDone: closeComposer,
							showSample: videoCount === 0
						})
					]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: folderOpen,
				onOpenChange: setFolderOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-lg font-bold",
							children: "Nova pasta"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-1 mb-4 text-sm text-muted",
							children: "Uma fila só com o que você escolher. Ex.: noite, jogos, aulas."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "grid gap-3",
							onSubmit: (event) => {
								event.preventDefault();
								if (!createPlaylist(folderName)) {
									setFolderError("Dá um nome para a pasta.");
									return;
								}
								setFolderName("");
								setFolderError(null);
								setFolderOpen(false);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: folderName,
									onChange: (event) => setFolderName(event.target.value),
									placeholder: "Nome da pasta",
									className: "min-h-11 rounded-lg border border-line bg-bg px-3",
									autoFocus: true
								}),
								folderError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-accent",
									children: folderError
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "tap min-h-11 rounded-lg bg-accent font-semibold text-accent-ink",
									children: "Criar pasta"
								})
							]
						})
					]
				})] })
			})
		]
	});
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-9 place-items-center rounded-lg bg-accent text-accent-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 fill-current" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-lg font-extrabold tracking-tight",
				children: "Depois"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: "vídeos do X, no seu tempo"
			})]
		})]
	});
}
function NavLink({ to, params, active, icon, label, count }) {
	if (to === "/") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		search: { add: void 0 },
		className: cn("flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium", active ? "bg-raised text-fg" : "text-muted hover:bg-raised hover:text-fg"),
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "min-w-0 flex-1 truncate",
			children: label
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/p/$playlistId",
		params: params ?? { playlistId: "inbox" },
		className: cn("flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium", active ? "bg-raised text-fg" : "text-muted hover:bg-raised hover:text-fg"),
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 truncate",
				children: label
			}),
			typeof count === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs tabular-nums text-muted",
				children: count
			}) : null
		]
	});
}
function SidebarFoot({ origin }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-line px-4 py-4 text-xs text-pretty text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fica salvo neste navegador." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "mt-3 hidden md:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer font-medium text-fg",
					children: "Atalho dentro do x.com"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "Arraste o botão para a barra de favoritos. No navegador, abra um vídeo do X e clique nele."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#salvar",
					ref: (node) => {
						if (node && origin) node.href = bookmarklet(origin);
					},
					onClick: (event) => event.preventDefault(),
					className: "mt-2 inline-flex min-h-11 items-center rounded-lg border border-line bg-raised px-3 text-sm font-semibold text-fg",
					children: "Salvar no Depois"
				})
			]
		})]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-ApDKU1-5.css";
var Route$3 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Depois" },
			{
				name: "description",
				content: "Pastas para assistir depois os vídeos do X que você separou."
			},
			{
				name: "theme-color",
				content: "#09090b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootComponent,
	notFoundComponent: NotFound
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center",
				toastOptions: { className: "border border-line bg-raised text-fg" }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "Essa página não existe"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "A biblioteca continua onde você deixou."
		})]
	});
}
var $$splitComponentImporter$2 = () => import("./routes-nem-Np8v.mjs");
var Route$2 = createFileRoute("/")({
	validateSearch: (search) => {
		if (typeof search.add === "string" && search.add.length > 0 && search.add.length < 500) return { add: search.add };
		return {};
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./p._playlistId-CFi0xNmP.mjs");
var Route$1 = createFileRoute("/p/$playlistId")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./watch._videoId-DLptkkk3.mjs");
var Route = createFileRoute("/watch/$videoId")({
	validateSearch: (search) => ({ list: typeof search.list === "string" && search.list.length < 80 ? search.list : void 0 }),
	loader: ({ params }) => resolveVideo({ data: { ref: params.videoId } }),
	pendingComponent: WatchPending,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function WatchPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-6 lg:grid-cols-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-video animate-pulse rounded-xl bg-raised" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-7 w-2/3 rounded bg-raised" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-4 w-1/3 rounded bg-raised" })
			]
		})
	});
}
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	PPlaylistIdRoute: Route$1.update({
		id: "/p/$playlistId",
		path: "/p/$playlistId",
		getParentRoute: () => Route$3
	}),
	WatchVideoIdRoute: Route.update({
		id: "/watch/$videoId",
		path: "/watch/$videoId",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { AddVideoForm as a, useLibrary as c, useServerFn as d, Route$2 as i, videosIn as l, Route as n, cn as o, Route$1 as r, allVideos as s, router_exports as t, resolveVideo as u };
