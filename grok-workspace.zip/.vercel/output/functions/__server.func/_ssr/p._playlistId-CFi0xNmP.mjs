import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Trash2, u as Pencil } from "../_libs/lucide-react.mjs";
import { c as useLibrary, l as videosIn, r as Route$1 } from "./router-DSBZPn7q.mjs";
import { t as LibraryView } from "./library-view-kYs4pwwR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/p._playlistId-CFi0xNmP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlaylistPage() {
	const { playlistId } = Route$1.useParams();
	const navigate = useNavigate();
	const { playlist, videos } = useLibrary((state) => {
		const playlist = state.playlists.find((item) => item.id === playlistId);
		return {
			playlist,
			videos: videosIn(playlist, state.videos)
		};
	});
	const openComposer = useLibrary((state) => state.openComposer);
	const renamePlaylist = useLibrary((state) => state.renamePlaylist);
	const deletePlaylist = useLibrary((state) => state.deletePlaylist);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)(playlist?.name ?? "");
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	if (!playlist) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "Essa pasta não existe"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Ela pode ter sido apagada neste navegador."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryView, {
		title: playlist.name,
		videos,
		playlistId: playlist.id,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					renamePlaylist(playlist.id, name);
					setEditing(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (event) => setName(event.target.value),
					className: "min-h-11 rounded-lg border border-line bg-surface px-3",
					"aria-label": "Nome da pasta"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "tap min-h-11 rounded-lg bg-accent px-3 text-sm font-semibold text-accent-ink",
					children: "Salvar"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tap grid size-11 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg",
				"aria-label": "Renomear pasta",
				onClick: () => {
					setName(playlist.name);
					setEditing(true);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
			}), playlist.id !== "inbox" ? confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tap min-h-11 rounded-lg px-3 text-sm font-semibold text-accent",
				onClick: () => {
					deletePlaylist(playlist.id);
					navigate({
						to: "/",
						search: {}
					});
				},
				children: "Apagar pasta"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tap grid size-11 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg",
				"aria-label": "Apagar pasta",
				onClick: () => setConfirmDelete(true),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
			}) : null]
		}),
		empty: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-lg py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold text-balance",
					children: playlist.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-pretty text-muted",
					children: "Essa pasta ainda está vazia. Guarde aqui os vídeos que você quer ver juntos."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap mt-5 min-h-11 rounded-lg bg-accent px-4 font-semibold text-accent-ink",
					onClick: () => openComposer(playlist.id),
					children: "Adicionar vídeo"
				})
			]
		})
	});
}
//#endregion
export { PlaylistPage as component };
