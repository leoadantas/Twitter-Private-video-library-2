import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { l as Play, v as Ellipsis, y as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as useLibrary, o as cn } from "./router-DSBZPn7q.mjs";
import { a as primaryClip, i as matchesQuery, n as formatClock, o as videoTitle, r as formatLoose } from "./x-url-CAO-RKT4.mjs";
import { a as DropdownMenuItemIndicator, c as DropdownMenuSubContent, i as DropdownMenuItem, l as DropdownMenuSubTrigger, n as DropdownMenuCheckboxItem, o as DropdownMenuPortal, r as DropdownMenuContent, s as DropdownMenuSub, t as DropdownMenu, u as DropdownMenuTrigger } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { n as formatDistanceToNow, t as ptBR } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-view-kYs4pwwR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VideoCard({ video, playlistId }) {
	const playlists = useLibrary((state) => state.playlists);
	const toggleMembership = useLibrary((state) => state.toggleMembership);
	const removeFromLibrary = useLibrary((state) => state.removeFromLibrary);
	const removeFromPlaylist = useLibrary((state) => state.removeFromPlaylist);
	const restore = useLibrary((state) => state.restore);
	const setCompleted = useLibrary((state) => state.setCompleted);
	const [broken, setBroken] = (0, import_react.useState)(false);
	const clip = primaryClip(video);
	const title = videoTitle(video);
	const progress = clip && clip.durationSec > 0 ? Math.min(1, video.positionSec / clip.durationSec) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/watch/$videoId",
			params: { videoId: video.id },
			search: { list: playlistId },
			className: "relative block overflow-hidden rounded-xl border border-line bg-raised",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-video",
				children: [
					clip?.thumbnailUrl && !broken ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: clip.thumbnailUrl,
						alt: "",
						className: "size-full object-cover motion-safe:transition-transform motion-safe:duration-300 motion-safe:group-hover:scale-105",
						onError: () => setBroken(true)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-full place-items-center text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-8" })
					}),
					clip && clip.durationSec > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute right-2 bottom-2 rounded bg-bg/80 px-1.5 py-0.5 text-xs font-medium tabular-nums",
						children: formatClock(clip.durationSec)
					}) : null,
					video.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute top-2 left-2 inline-flex items-center gap-1 rounded bg-bg/80 px-1.5 py-0.5 text-xs font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-accent" }), "Visto"]
					}) : null,
					progress > .02 && !video.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-x-0 bottom-0 h-1 bg-fg/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block h-full bg-accent",
							style: { width: `${progress * 100}%` }
						})
					}) : null
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-start gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/watch/$videoId",
				params: { videoId: video.id },
				search: { list: playlistId },
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "line-clamp-2 text-sm font-semibold text-balance",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 truncate text-xs text-muted",
					children: [
						"@",
						video.authorHandle,
						" · ",
						formatDistanceToNow(video.addedAt, {
							addSuffix: true,
							locale: ptBR
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				"aria-label": `Ações de ${title}`,
				className: "tap grid size-11 shrink-0 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				sideOffset: 6,
				className: "z-50 w-56 rounded-xl border border-line bg-surface p-1 shadow-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						className: "cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised",
						onSelect: () => setCompleted(video.id, !video.completed),
						children: video.completed ? "Marcar como não visto" : "Marcar como visto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuSub, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubTrigger, {
						className: "cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised",
						children: "Pastas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSubContent, {
						className: "z-50 w-52 rounded-xl border border-line bg-surface p-1 shadow-xl",
						sideOffset: 8,
						children: playlists.map((playlist) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuCheckboxItem, {
							checked: playlist.videoIds.includes(video.id),
							onSelect: (event) => event.preventDefault(),
							onCheckedChange: () => toggleMembership(video.id, playlist.id),
							className: "relative cursor-pointer rounded-lg py-2 pr-3 pl-8 text-sm outline-none data-[highlighted]:bg-raised",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItemIndicator, {
								className: "absolute left-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-accent" })
							}), playlist.name]
						}, playlist.id))
					}) })] }),
					playlistId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						className: "cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised",
						onSelect: () => {
							removeFromPlaylist(video.id, playlistId);
							const name = playlists.find((playlist) => playlist.id === playlistId)?.name ?? "pasta";
							toast(`Tirado de ${name}`);
						},
						children: "Tirar desta pasta"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
						className: "cursor-pointer rounded-lg px-3 py-2 text-sm text-accent outline-none data-[highlighted]:bg-raised",
						onSelect: () => {
							const snapshot = removeFromLibrary(video.id);
							if (!snapshot) return;
							toast("Removido da biblioteca", { action: {
								label: "Desfazer",
								onClick: () => restore(snapshot)
							} });
						},
						children: "Remover da biblioteca"
					})
				]
			}) })] })]
		})]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "Todos"
	},
	{
		id: "open",
		label: "Para ver"
	},
	{
		id: "done",
		label: "Vistos"
	}
];
function LibraryView({ title, videos, playlistId, empty, actions }) {
	const query = useLibrary((state) => state.query);
	const [filter, setFilter] = (0, import_react.useState)("all");
	if (videos.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-4 flex justify-end",
		children: actions
	}) : null, empty] });
	const shown = videos.filter((video) => {
		if (!matchesQuery(video, query)) return false;
		if (filter === "open") return !video.completed;
		if (filter === "done") return video.completed;
		return true;
	});
	const seconds = videos.reduce((total, video) => total + (primaryClip(video)?.durationSec ?? 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-balance",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted tabular-nums",
				children: [
					videos.length,
					" ",
					videos.length === 1 ? "vídeo" : "vídeos",
					" · ",
					formatLoose(seconds)
				]
			})] }), actions]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex flex-wrap gap-2",
			children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item.id),
				className: cn("tap min-h-11 rounded-full border px-3 text-sm font-medium", filter === item.id ? "border-accent bg-accent text-accent-ink" : "border-line text-muted hover:text-fg"),
				children: item.label
			}, item.id))
		}),
		shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Nada com esse filtro."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2 xl:grid-cols-3",
			children: shown.map((video) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
				video,
				playlistId
			}, video.id))
		})
	] });
}
//#endregion
export { LibraryView as t };
