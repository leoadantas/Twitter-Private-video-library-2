//#region node_modules/.nitro/vite/services/ssr/assets/x-url-CAO-RKT4.js
var HOSTS = /* @__PURE__ */ new Set([
	"x.com",
	"twitter.com",
	"mobile.x.com",
	"mobile.twitter.com",
	"fxtwitter.com",
	"vxtwitter.com",
	"fixupx.com"
]);
function extractStatusId(input) {
	const trimmed = input.trim();
	if (/^\d{1,22}$/.test(trimmed)) return trimmed;
	try {
		const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
		const url = new URL(withProto);
		const host = url.hostname.replace(/^www\./, "").toLowerCase();
		if (!HOSTS.has(host)) return null;
		return url.pathname.match(/\/status(?:es)?\/(\d{1,22})/)?.[1] ?? null;
	} catch {
		return null;
	}
}
function videoTitle(video) {
	return video.text.replace(/\s+/g, " ").trim() || `Vídeo de @${video.authorHandle}`;
}
function formatClock(sec) {
	if (!Number.isFinite(sec) || sec < 0) sec = 0;
	const total = Math.floor(sec);
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function formatLoose(sec) {
	const s = Math.max(0, Math.round(sec));
	if (s < 60) return `${s} s`;
	const minutes = Math.round(s / 60);
	if (minutes < 60) return `${minutes} min`;
	const h = Math.floor(minutes / 60);
	const m = minutes % 60;
	return m ? `${h} h ${m} min` : `${h} h`;
}
function primaryClip(video) {
	const index = video.clipIndex ?? 0;
	return video.clips[index] ?? video.clips[0];
}
function matchesQuery(video, query) {
	const needle = query.trim().toLowerCase();
	if (!needle) return true;
	return video.text.toLowerCase().includes(needle) || video.authorName.toLowerCase().includes(needle) || video.authorHandle.toLowerCase().includes(needle);
}
//#endregion
export { primaryClip as a, matchesQuery as i, formatClock as n, videoTitle as o, formatLoose as r, extractStatusId as t };
