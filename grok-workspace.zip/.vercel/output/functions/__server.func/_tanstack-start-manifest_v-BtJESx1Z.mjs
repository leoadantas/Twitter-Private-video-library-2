//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BtJESx1Z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/p/$playlistId",
			"/watch/$videoId"
		],
		preloads: [
			"/assets/index-AkS8M0jj.js",
			"/assets/preload-helper-D5cWGCtI.js",
			"/assets/resolve-video-BraKZWin.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-AkS8M0jj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CGimTLJ5.js", "/assets/library-view-4evunZcS.js"]
	},
	"/p/$playlistId": {
		filePath: "/workspace/src/routes/p.$playlistId.tsx",
		children: void 0,
		preloads: ["/assets/p._playlistId-8dZ_DIqT.js", "/assets/library-view-4evunZcS.js"]
	},
	"/watch/$videoId": {
		filePath: "/workspace/src/routes/watch.$videoId.tsx",
		children: void 0,
		preloads: ["/assets/watch._videoId-jTxjUjbO.js", "/assets/x-url-BHdsS1Na.js"]
	}
} });
//#endregion
export { tsrStartManifest };
