import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Pencil, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { LibraryView } from "@/components/library-view";
import { useLibrary, videosIn } from "@/lib/library";
import { INBOX_ID } from "@/lib/types";

export const Route = createFileRoute("/p/$playlistId")({
  component: PlaylistPage,
});

function PlaylistPage() {
  const { playlistId } = Route.useParams();
  const navigate = useNavigate();
  const playlists = useLibrary((state) => state.playlists);
  const videoMap = useLibrary((state) => state.videos);
  const playlist = playlists.find((item) => item.id === playlistId);
  const videos = useMemo(() => videosIn(playlist, videoMap), [playlist, videoMap]);
  const openComposer = useLibrary((state) => state.openComposer);
  const renamePlaylist = useLibrary((state) => state.renamePlaylist);
  const deletePlaylist = useLibrary((state) => state.deletePlaylist);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(playlist?.name ?? "");
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!playlist) {
    return (
      <div className="py-16">
        <h1 className="text-2xl font-bold">Essa pasta não existe</h1>
        <p className="mt-2 text-sm text-muted">Ela pode ter sido apagada neste navegador.</p>
      </div>
    );
  }

  return (
    <LibraryView
      title={playlist.name}
      videos={videos}
      playlistId={playlist.id}
      actions={
        <div className="flex items-center gap-1">
          {editing ? (
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                renamePlaylist(playlist.id, name);
                setEditing(false);
              }}
            >
              <input
                value={name}
                onChange={(event) => setName(event.target.value)}
                className="min-h-11 rounded-lg border border-line bg-surface px-3"
                aria-label="Nome da pasta"
              />
              <button type="submit" className="tap min-h-11 rounded-lg bg-accent px-3 text-sm font-semibold text-accent-ink">
                Salvar
              </button>
            </form>
          ) : (
            <button
              type="button"
              className="tap grid size-11 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg"
              aria-label="Renomear pasta"
              onClick={() => {
                setName(playlist.name);
                setEditing(true);
              }}
            >
              <Pencil className="size-4" />
            </button>
          )}
          {playlist.id !== INBOX_ID ? (
            confirmDelete ? (
              <button
                type="button"
                className="tap min-h-11 rounded-lg px-3 text-sm font-semibold text-accent"
                onClick={() => {
                  deletePlaylist(playlist.id);
                  void navigate({ to: "/", search: {} });
                }}
              >
                Apagar pasta
              </button>
            ) : (
              <button
                type="button"
                className="tap grid size-11 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg"
                aria-label="Apagar pasta"
                onClick={() => setConfirmDelete(true)}
              >
                <Trash2 className="size-4" />
              </button>
            )
          ) : null}
        </div>
      }
      empty={
        <div className="max-w-lg py-8">
          <h1 className="text-2xl font-bold text-balance">{playlist.name}</h1>
          <p className="mt-2 text-pretty text-muted">Essa pasta ainda está vazia. Guarde aqui os vídeos que você quer ver juntos.</p>
          <button
            type="button"
            className="tap mt-5 min-h-11 rounded-lg bg-accent px-4 font-semibold text-accent-ink"
            onClick={() => openComposer(playlist.id)}
          >
            Adicionar vídeo
          </button>
        </div>
      }
    />
  );
}
