import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Check, ExternalLink } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Player } from "@/components/player";
import { allVideos, useLibrary, videosIn } from "@/lib/library";
import { resolveVideo } from "@/lib/resolve-video";
import type { Playlist, SavedVideo } from "@/lib/types";
import { formatClock, videoTitle } from "@/lib/x-url";

type WatchSearch = { list?: string };

export const Route = createFileRoute("/watch/$videoId")({
  validateSearch: (search: Record<string, unknown>): WatchSearch => ({
    list: typeof search.list === "string" && search.list.length < 80 ? search.list : undefined,
  }),
  loader: ({ params }) => resolveVideo({ data: { ref: params.videoId } }),
  pendingComponent: WatchPending,
  component: WatchPage,
});

function WatchPending() {
  return (
    <div className="grid gap-6 lg:grid-cols-4">
      <div className="lg:col-span-3">
        <div className="aspect-video animate-pulse rounded-xl bg-raised" />
        <div className="mt-4 h-7 w-2/3 rounded bg-raised" />
        <div className="mt-3 h-4 w-1/3 rounded bg-raised" />
      </div>
    </div>
  );
}

function WatchPage() {
  const { videoId } = Route.useParams();
  const { list } = Route.useSearch();
  const fresh = Route.useLoaderData();
  const navigate = useNavigate();
  const saved = useLibrary((state) => state.videos[videoId]);
  const playlists = useLibrary((state) => state.playlists);
  const videos = useLibrary((state) => state.videos);
  const refreshMeta = useLibrary((state) => state.refreshMeta);
  const saveTweet = useLibrary((state) => state.saveTweet);
  const setProgress = useLibrary((state) => state.setProgress);
  const setCompleted = useLibrary((state) => state.setCompleted);
  const setClipIndex = useLibrary((state) => state.setClipIndex);
  const removeFromLibrary = useLibrary((state) => state.removeFromLibrary);
  const restore = useLibrary((state) => state.restore);
  const autoplay = useLibrary((state) => state.autoplay);
  const setAutoplay = useLibrary((state) => state.setAutoplay);
  const [clip, setClip] = useState(saved?.clipIndex ?? 0);
  const [resumeFrom] = useState(() => (saved && !saved.completed && saved.positionSec > 3 ? saved.positionSec : 0));

  useEffect(() => {
    if (fresh.ok) refreshMeta(fresh.tweet);
  }, [fresh, refreshMeta]);

  const tweet = fresh.ok ? fresh.tweet : saved;
  if (!tweet) {
    return (
      <div className="max-w-lg py-10">
        <h1 className="text-2xl font-bold">Não deu para abrir</h1>
        <p className="mt-2 text-pretty text-muted">{fresh.ok ? "Vídeo indisponível." : fresh.message}</p>
        <Link to="/" search={{}} className="mt-4 inline-flex min-h-11 items-center font-semibold text-accent">
          Voltar para a biblioteca
        </Link>
      </div>
    );
  }

  const clips = fresh.ok ? fresh.tweet.clips : saved?.clips ?? [];
  const active = clips[clip] ?? clips[0];
  const title = videoTitle(tweet);
  const queue = queueAfter(videos, playlists, videoId, list);
  const next = queue[0];
  const playlistName = playlists.find((playlist) => playlist.id === list)?.name;

  function goNext(target = next) {
    if (!target) return;
    void navigate({
      to: "/watch/$videoId",
      params: { videoId: target.id },
      search: { list },
    });
  }

  return (
    <div className="grid items-start gap-6 lg:grid-cols-4">
      <div className="min-w-0 lg:col-span-3">
        {!fresh.ok && saved ? (
          <p className="mb-3 rounded-lg border border-line bg-surface px-3 py-2 text-sm text-muted">
            Não atualizei o link com o X. Tocando a cópia que já estava salva.
          </p>
        ) : null}
        {active ? (
          <Player
            key={`${tweet.id}:${clip}`}
            videoKey={`${tweet.id}:${clip}`}
            sources={active.sources}
            poster={active.thumbnailUrl}
            initialTime={saved && !saved.completed && (saved.clipIndex ?? 0) === clip ? saved.positionSec : 0}
            title={title}
            onProgress={(position, duration) => {
              if (saved) setProgress(saved.id, position, duration);
            }}
            onComplete={() => {
              if (saved) setCompleted(saved.id, true);
            }}
            nextTitle={next ? videoTitle(next) : undefined}
            onNext={next ? () => goNext() : undefined}
          />
        ) : null}
        <h1 className="mt-4 text-xl font-bold text-balance sm:text-2xl">{title}</h1>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <a
            href={`https://x.com/${tweet.authorHandle}`}
            target="_blank"
            rel="noreferrer"
            className="flex min-w-0 items-center gap-3"
          >
            {tweet.avatarUrl ? (
              <img src={tweet.avatarUrl} alt="" referrerPolicy="no-referrer" className="size-10 rounded-full object-cover" />
            ) : (
              <span className="grid size-10 place-items-center rounded-full bg-raised text-sm font-bold">
                {tweet.authorName.slice(0, 1)}
              </span>
            )}
            <span className="min-w-0">
              <span className="block truncate font-semibold">{tweet.authorName}</span>
              <span className="block text-sm text-muted">@{tweet.authorHandle}</span>
            </span>
          </a>
          <span className="flex-1" />
          {saved ? (
            <button
              type="button"
              className="tap inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold"
              onClick={() => setCompleted(saved.id, !saved.completed)}
            >
              <Check className="size-4 text-accent" />
              {saved.completed ? "Visto" : "Marcar visto"}
            </button>
          ) : (
            <button
              type="button"
              className="tap min-h-11 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink"
              onClick={() => {
                if (!fresh.ok) return;
                saveTweet(fresh.tweet, list || "inbox");
                toast("Salvo para depois");
              }}
            >
              Salvar para depois
            </button>
          )}
          <a
            href={tweet.url}
            target="_blank"
            rel="noreferrer"
            className="tap inline-flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm font-semibold"
          >
            Abrir no X
            <ExternalLink className="size-4" />
          </a>
          {saved ? (
            <button
              type="button"
              className="min-h-11 px-2 text-sm text-muted"
              onClick={() => {
                const snapshot = removeFromLibrary(saved.id);
                if (!snapshot) return;
                toast("Removido da biblioteca", {
                  action: { label: "Desfazer", onClick: () => restore(snapshot) },
                });
                void navigate({ to: "/", search: {} });
              }}
            >
              Remover
            </button>
          ) : null}
        </div>
        {resumeFrom > 0 ? <p className="mt-3 text-sm text-muted">Continua de {formatClock(resumeFrom)}.</p> : null}
        {clips.length > 1 ? (
          <div className="mt-4 flex flex-wrap gap-2">
            {clips.map((item, index) => (
              <button
                key={item.sources[0]?.url ?? index}
                type="button"
                onClick={() => {
                  setClip(index);
                  if (saved) setClipIndex(saved.id, index);
                }}
                className={
                  index === clip
                    ? "min-h-11 rounded-lg bg-accent px-3 text-sm font-semibold text-accent-ink"
                    : "tap min-h-11 rounded-lg border border-line px-3 text-sm"
                }
              >
                Vídeo {index + 1}
                {item.durationSec > 0 ? ` · ${formatClock(item.durationSec)}` : ""}
              </button>
            ))}
          </div>
        ) : null}
        <p className="mt-4 text-sm text-pretty text-muted sm:hidden">
          <button type="button" className="font-medium text-fg" onClick={() => setAutoplay(!autoplay)}>
            {autoplay ? "Autoplay ligado" : "Autoplay desligado"}
          </button>
        </p>
      </div>
      <aside className="rounded-xl border border-line bg-surface p-3">
        <h2 className="px-1 text-sm font-semibold">{playlistName ? `A seguir em ${playlistName}` : "A seguir"}</h2>
        {queue.length === 0 ? (
          <p className="px-1 py-4 text-sm text-muted">Fim da fila.</p>
        ) : (
          <ul className="mt-2 grid gap-2">
            {queue.map((item) => {
              const itemClip = item.clips[item.clipIndex] ?? item.clips[0];
              return (
                <li key={item.id}>
                  <button type="button" onClick={() => goNext(item)} className="flex w-full gap-3 rounded-lg p-1 text-left hover:bg-raised">
                    <span className="relative block w-28 shrink-0 overflow-hidden rounded-md bg-raised">
                      {itemClip?.thumbnailUrl ? (
                        <img src={itemClip.thumbnailUrl} alt="" referrerPolicy="no-referrer" className="aspect-video w-full object-cover" />
                      ) : (
                        <span className="block aspect-video" />
                      )}
                      {itemClip && itemClip.durationSec > 0 ? (
                        <span className="absolute right-1 bottom-1 rounded bg-bg/80 px-1 text-xs tabular-nums">
                          {formatClock(itemClip.durationSec)}
                        </span>
                      ) : null}
                    </span>
                    <span className="min-w-0 py-1">
                      <span className="line-clamp-2 text-sm font-medium text-balance">{videoTitle(item)}</span>
                      <span className="mt-1 block truncate text-xs text-muted">@{item.authorHandle}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </aside>
    </div>
  );
}

function queueAfter(
  videos: Record<string, SavedVideo>,
  playlists: Playlist[],
  currentId: string,
  list: string | undefined,
): SavedVideo[] {
  if (list) {
    const playlist = playlists.find((item) => item.id === list);
    const ordered = videosIn(playlist, videos);
    const index = ordered.findIndex((video) => video.id === currentId);
    return index >= 0 ? ordered.slice(index + 1) : ordered.filter((video) => video.id !== currentId);
  }
  return allVideos(videos).filter((video) => video.id !== currentId && !video.completed);
}
