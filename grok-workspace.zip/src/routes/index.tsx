import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef } from "react";
import { toast } from "sonner";
import { AddVideoForm } from "@/components/add-video-form";
import { LibraryView } from "@/components/library-view";
import { allVideos, useLibrary } from "@/lib/library";
import { resolveVideo } from "@/lib/resolve-video";

type HomeSearch = { add?: string };

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): HomeSearch => {
    if (typeof search.add === "string" && search.add.length > 0 && search.add.length < 500) {
      return { add: search.add };
    }
    return {};
  },
  component: HomePage,
});

function HomePage() {
  const { add } = Route.useSearch();
  const navigate = useNavigate();
  const resolve = useServerFn(resolveVideo);
  const videoMap = useLibrary((state) => state.videos);
  const videos = useMemo(() => allVideos(videoMap), [videoMap]);
  const saveTweet = useLibrary((state) => state.saveTweet);
  const started = useRef(false);

  useEffect(() => {
    if (!add || started.current) return;
    started.current = true;
    void (async () => {
      const result = await resolve({ data: { ref: add } });
      if (!result.ok) {
        toast.error(result.message);
        await navigate({ to: "/", search: {}, replace: true });
        return;
      }
      saveTweet(result.tweet, "inbox");
      await navigate({
        to: "/watch/$videoId",
        params: { videoId: result.tweet.id },
        search: { list: "inbox" },
        replace: true,
      });
    })();
  }, [add, navigate, resolve, saveTweet]);

  if (add) {
    return (
      <div className="py-16">
        <h1 className="text-2xl font-bold">Salvando vídeo…</h1>
        <p className="mt-2 text-sm text-muted">Buscando o post no X.</p>
      </div>
    );
  }

  return (
    <LibraryView
      title="Todos os vídeos"
      videos={videos}
      empty={
        <div className="mx-auto max-w-2xl py-6 sm:py-10">
          <p className="text-sm font-semibold tracking-wide text-accent">Biblioteca pessoal</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-balance sm:text-4xl">
            Os vídeos do X que você não pode ver agora.
          </h1>
          <p className="mt-3 max-w-xl text-pretty text-muted">
            O app do X não deixa instalar outra tela lá dentro. Cole o link aqui, separe em pastas e assista quando der — com fila, progresso e só o que você escolheu.
          </p>
          <div className="mt-6 rounded-2xl border border-line bg-surface p-4">
            <AddVideoForm showSample />
          </div>
          <ol className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              ["1", "Abra o vídeo no X"],
              ["2", "Compartilhar e copiar o link"],
              ["3", "Cole aqui e escolha a pasta"],
            ].map(([step, label]) => (
              <li key={step} className="rounded-xl border border-line bg-surface px-3 py-3">
                <span className="text-sm font-bold text-accent">{step}</span>
                <p className="mt-1 text-sm text-pretty">{label}</p>
              </li>
            ))}
          </ol>
        </div>
      }
    />
  );
}
