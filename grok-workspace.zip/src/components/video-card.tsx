import * as Menu from "@radix-ui/react-dropdown-menu";
import { Link } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Check, MoreHorizontal, Play } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLibrary } from "@/lib/library";
import type { SavedVideo } from "@/lib/types";
import { formatClock, primaryClip, videoTitle } from "@/lib/x-url";

export function VideoCard({ video, playlistId }: { video: SavedVideo; playlistId?: string }) {
  const playlists = useLibrary((state) => state.playlists);
  const toggleMembership = useLibrary((state) => state.toggleMembership);
  const removeFromLibrary = useLibrary((state) => state.removeFromLibrary);
  const removeFromPlaylist = useLibrary((state) => state.removeFromPlaylist);
  const restore = useLibrary((state) => state.restore);
  const setCompleted = useLibrary((state) => state.setCompleted);
  const [broken, setBroken] = useState(false);
  const clip = primaryClip(video);
  const title = videoTitle(video);
  const progress = clip && clip.durationSec > 0 ? Math.min(1, video.positionSec / clip.durationSec) : 0;

  return (
    <article className="group min-w-0">
      <Link
        to="/watch/$videoId"
        params={{ videoId: video.id }}
        search={{ list: playlistId }}
        className="relative block overflow-hidden rounded-xl border border-line bg-raised"
      >
        <div className="relative aspect-video">
          {clip?.thumbnailUrl && !broken ? (
            <img
              src={clip.thumbnailUrl}
              alt=""
              referrerPolicy="no-referrer"
              className="size-full object-cover motion-safe:transition-transform motion-safe:duration-300 motion-safe:group-hover:scale-105"
              onError={() => setBroken(true)}
            />
          ) : (
            <span className="grid size-full place-items-center text-muted">
              <Play className="size-8" />
            </span>
          )}
          {clip && clip.durationSec > 0 ? (
            <span className="absolute right-2 bottom-2 rounded bg-bg/80 px-1.5 py-0.5 text-xs font-medium tabular-nums">
              {formatClock(clip.durationSec)}
            </span>
          ) : null}
          {video.completed ? (
            <span className="absolute top-2 left-2 inline-flex items-center gap-1 rounded bg-bg/80 px-1.5 py-0.5 text-xs font-medium">
              <Check className="size-3 text-accent" />
              Visto
            </span>
          ) : null}
          {progress > 0.02 && !video.completed ? (
            <span className="absolute inset-x-0 bottom-0 h-1 bg-fg/20">
              <span className="block h-full bg-accent" style={{ width: `${progress * 100}%` }} />
            </span>
          ) : null}
        </div>
      </Link>
      <div className="mt-3 flex items-start gap-2">
        <Link
          to="/watch/$videoId"
          params={{ videoId: video.id }}
          search={{ list: playlistId }}
          className="min-w-0 flex-1"
        >
          <h2 className="line-clamp-2 text-sm font-semibold text-balance">{title}</h2>
          <p className="mt-1 truncate text-xs text-muted">
            @{video.authorHandle} · {formatDistanceToNow(video.addedAt, { addSuffix: true, locale: ptBR })}
          </p>
        </Link>
        <Menu.Root>
          <Menu.Trigger
            aria-label={`Ações de ${title}`}
            className="tap grid size-11 shrink-0 place-items-center rounded-lg text-muted hover:bg-raised hover:text-fg"
          >
            <MoreHorizontal className="size-4" />
          </Menu.Trigger>
          <Menu.Portal>
            <Menu.Content
              align="end"
              sideOffset={6}
              className="z-50 w-56 rounded-xl border border-line bg-surface p-1 shadow-xl"
            >
              <Menu.Item
                className="cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised"
                onSelect={() => setCompleted(video.id, !video.completed)}
              >
                {video.completed ? "Marcar como não visto" : "Marcar como visto"}
              </Menu.Item>
              <Menu.Sub>
                <Menu.SubTrigger className="cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised">
                  Pastas
                </Menu.SubTrigger>
                <Menu.Portal>
                  <Menu.SubContent className="z-50 w-52 rounded-xl border border-line bg-surface p-1 shadow-xl" sideOffset={8}>
                    {playlists.map((playlist) => (
                      <Menu.CheckboxItem
                        key={playlist.id}
                        checked={playlist.videoIds.includes(video.id)}
                        onSelect={(event) => event.preventDefault()}
                        onCheckedChange={() => toggleMembership(video.id, playlist.id)}
                        className="relative cursor-pointer rounded-lg py-2 pr-3 pl-8 text-sm outline-none data-[highlighted]:bg-raised"
                      >
                        <Menu.ItemIndicator className="absolute left-2">
                          <Check className="size-4 text-accent" />
                        </Menu.ItemIndicator>
                        {playlist.name}
                      </Menu.CheckboxItem>
                    ))}
                  </Menu.SubContent>
                </Menu.Portal>
              </Menu.Sub>
              {playlistId ? (
                <Menu.Item
                  className="cursor-pointer rounded-lg px-3 py-2 text-sm outline-none data-[highlighted]:bg-raised"
                  onSelect={() => {
                    removeFromPlaylist(video.id, playlistId);
                    const name = playlists.find((playlist) => playlist.id === playlistId)?.name ?? "pasta";
                    toast(`Tirado de ${name}`);
                  }}
                >
                  Tirar desta pasta
                </Menu.Item>
              ) : null}
              <Menu.Item
                className="cursor-pointer rounded-lg px-3 py-2 text-sm text-accent outline-none data-[highlighted]:bg-raised"
                onSelect={() => {
                  const snapshot = removeFromLibrary(video.id);
                  if (!snapshot) return;
                  toast("Removido da biblioteca", {
                    action: { label: "Desfazer", onClick: () => restore(snapshot) },
                  });
                }}
              >
                Remover da biblioteca
              </Menu.Item>
            </Menu.Content>
          </Menu.Portal>
        </Menu.Root>
      </div>
    </article>
  );
}
