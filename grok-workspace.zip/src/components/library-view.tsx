import { useState, type ReactNode } from "react";
import { VideoCard } from "@/components/video-card";
import { useLibrary } from "@/lib/library";
import type { SavedVideo } from "@/lib/types";
import { cn } from "@/lib/cn";
import { formatLoose, matchesQuery, primaryClip } from "@/lib/x-url";

type Filter = "all" | "open" | "done";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "Todos" },
  { id: "open", label: "Para ver" },
  { id: "done", label: "Vistos" },
];

export function LibraryView({
  title,
  videos,
  playlistId,
  empty,
  actions,
}: {
  title: string;
  videos: SavedVideo[];
  playlistId?: string;
  empty: ReactNode;
  actions?: ReactNode;
}) {
  const query = useLibrary((state) => state.query);
  const [filter, setFilter] = useState<Filter>("all");

  if (videos.length === 0) {
    return (
      <section>
        {actions ? <div className="mb-4 flex justify-end">{actions}</div> : null}
        {empty}
      </section>
    );
  }

  const shown = videos.filter((video) => {
    if (!matchesQuery(video, query)) return false;
    if (filter === "open") return !video.completed;
    if (filter === "done") return video.completed;
    return true;
  });
  const seconds = videos.reduce((total, video) => total + (primaryClip(video)?.durationSec ?? 0), 0);

  return (
    <section>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-balance">{title}</h1>
          <p className="mt-1 text-sm text-muted tabular-nums">
            {videos.length} {videos.length === 1 ? "vídeo" : "vídeos"} · {formatLoose(seconds)}
          </p>
        </div>
        {actions}
      </div>
      <div className="mb-5 flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={cn(
              "tap min-h-11 rounded-full border px-3 text-sm font-medium",
              filter === item.id ? "border-accent bg-accent text-accent-ink" : "border-line text-muted hover:text-fg",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      {shown.length === 0 ? (
        <p className="text-sm text-muted">Nada com esse filtro.</p>
      ) : (
        <div className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2 xl:grid-cols-3">
          {shown.map((video) => (
            <VideoCard key={video.id} video={video} playlistId={playlistId} />
          ))}
        </div>
      )}
    </section>
  );
}
