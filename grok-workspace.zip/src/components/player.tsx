import { Maximize, Minimize, Pause, Play, SkipForward, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLibrary } from "@/lib/library";
import type { Source } from "@/lib/types";
import { formatClock } from "@/lib/x-url";
import { cn } from "@/lib/cn";

const RATES = [1, 1.25, 1.5, 2];

function pickSource(sources: Source[]): Source | undefined {
  return (
    sources.find((source) => source.label === "720p") ??
    sources.find((source) => source.bitrate >= 800_000 && source.bitrate <= 2_800_000) ??
    sources[Math.min(sources.length - 1, Math.floor(sources.length / 2))]
  );
}

function typingTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  return Boolean(target.closest("input, textarea, select, [contenteditable='true']"));
}

export function Player({
  videoKey,
  sources,
  poster,
  initialTime,
  title,
  onProgress,
  onComplete,
  nextTitle,
  onNext,
}: {
  videoKey: string;
  sources: Source[];
  poster?: string;
  initialTime: number;
  title: string;
  onProgress: (position: number, duration: number) => void;
  onComplete: () => void;
  nextTitle?: string;
  onNext?: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef(onProgress);
  const completeRef = useRef(onComplete);
  const nextRef = useRef(onNext);
  progressRef.current = onProgress;
  completeRef.current = onComplete;
  nextRef.current = onNext;

  const volume = useLibrary((state) => state.volume);
  const setVolume = useLibrary((state) => state.setVolume);
  const autoplay = useLibrary((state) => state.autoplay);
  const setAutoplay = useLibrary((state) => state.setAutoplay);

  const chosen = pickSource(sources);
  const [source, setSource] = useState<Source | undefined>(chosen);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [ended, setEnded] = useState(false);
  const [canceled, setCanceled] = useState(false);
  const [count, setCount] = useState(5);
  const [fullscreen, setFullscreen] = useState(false);
  const [failed, setFailed] = useState(false);
  const [rate, setRate] = useState(1);
  const lastSave = useRef(0);
  const didInit = useRef(false);
  const pendingSeek = useRef<number | null>(null);
  const resumePlay = useRef(false);

  const sourceKey = sources.map((item) => `${item.label}:${item.url}`).join("|");

  useEffect(() => {
    setSource(pickSource(sources));
    setEnded(false);
    setCanceled(false);
    setFailed(false);
    setPlaying(false);
    setTime(0);
    didInit.current = false;
    // Reset only when the actual file list changes, not on parent re-renders.
  }, [videoKey, sourceKey]);

  useEffect(() => {
    const element = videoRef.current;
    if (element) element.volume = muted ? 0 : volume;
  }, [volume, muted]);

  useEffect(() => {
    const onChange = () => setFullscreen(document.fullscreenElement === frameRef.current);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  useEffect(() => {
    if (!ended || canceled || !autoplay || !onNext) return;
    setCount(5);
    let left = 5;
    const timer = window.setInterval(() => {
      left -= 1;
      setCount(left);
      if (left <= 0) {
        window.clearInterval(timer);
        nextRef.current?.();
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, [ended, canceled, autoplay, onNext, videoKey]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (typingTarget(event.target)) return;
      const element = videoRef.current;
      if (!element) return;
      if (event.code === "Space" || event.key === "k") {
        event.preventDefault();
        toggle();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        seek(element.currentTime + 5);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        seek(element.currentTime - 5);
      } else if (event.key === "f") {
        event.preventDefault();
        void toggleFullscreen();
      } else if (event.key === "m") {
        event.preventDefault();
        setMuted((value) => !value);
      } else if (event.key === "n" && nextRef.current) {
        event.preventDefault();
        nextRef.current();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function seek(next: number) {
    const element = videoRef.current;
    if (!element) return;
    const max = Number.isFinite(element.duration) ? element.duration : next;
    const value = Math.min(Math.max(0, next), max);
    element.currentTime = value;
    setTime(value);
    setEnded(false);
    lastSave.current = performance.now();
    progressRef.current(value, element.duration || 0);
  }

  function toggle() {
    const element = videoRef.current;
    if (!element) return;
    if (element.paused) {
      setEnded(false);
      void element.play();
    } else {
      element.pause();
    }
  }

  async function toggleFullscreen() {
    const frame = frameRef.current;
    if (!frame) return;
    if (document.fullscreenElement === frame) await document.exitFullscreen();
    else await frame.requestFullscreen();
  }

  function changeSource(next: Source) {
    const element = videoRef.current;
    pendingSeek.current = element?.currentTime ?? 0;
    resumePlay.current = Boolean(element && !element.paused);
    didInit.current = true;
    setSource(next);
  }

  const percent = duration > 0 ? Math.min(100, (time / duration) * 100) : 0;

  return (
    <div ref={frameRef} className="overflow-hidden rounded-xl border border-line bg-bg">
      <div
        className="relative aspect-video bg-bg"
        onDoubleClick={() => void toggleFullscreen()}
      >
        {source ? (
          <video
            key={source.url}
            ref={videoRef}
            className="size-full bg-bg object-contain"
            poster={poster || undefined}
            playsInline
            preload="metadata"
            referrerPolicy="no-referrer"
            src={source.url}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onLoadedMetadata={(event) => {
              const element = event.currentTarget;
              element.playbackRate = rate;
              element.volume = muted ? 0 : volume;
              setDuration(element.duration || 0);
              if (pendingSeek.current != null) {
                element.currentTime = pendingSeek.current;
                pendingSeek.current = null;
                if (resumePlay.current) void element.play();
                return;
              }
              if (!didInit.current) {
                didInit.current = true;
                if (initialTime > 1 && initialTime < (element.duration || Infinity) - 1) {
                  element.currentTime = initialTime;
                  setTime(initialTime);
                }
              }
            }}
            onTimeUpdate={(event) => {
              const element = event.currentTarget;
              setTime(element.currentTime);
              if (Number.isFinite(element.duration)) setDuration(element.duration);
              const now = performance.now();
              if (now - lastSave.current > 2000) {
                lastSave.current = now;
                progressRef.current(element.currentTime, element.duration || 0);
              }
            }}
            onEnded={() => {
              const element = videoRef.current;
              setEnded(true);
              setPlaying(false);
              if (element) progressRef.current(element.duration || element.currentTime, element.duration || 0);
              completeRef.current();
            }}
            onError={() => setFailed(true)}
            onClick={toggle}
          />
        ) : (
          <div className="grid size-full place-items-center px-6 text-center text-sm text-muted">
            Não achei um arquivo de vídeo reproduzível nesse post.
          </div>
        )}

        {failed ? (
          <div className="absolute inset-0 grid place-items-center bg-bg/80 px-6 text-center">
            <p className="max-w-sm text-sm text-pretty">
              O X não entregou esse arquivo agora. Ele pode ter expirado ou o post saiu do ar.
            </p>
          </div>
        ) : null}

        {!playing && !ended && source && !failed ? (
          <button
            type="button"
            aria-label="Reproduzir"
            className="tap absolute inset-0 grid place-items-center"
            onClick={toggle}
          >
            <span className="grid size-16 place-items-center rounded-full bg-bg/75 text-fg">
              <Play className="size-7 fill-current" />
            </span>
          </button>
        ) : null}

        {ended ? (
          <div className="absolute inset-0 grid place-items-center gap-3 bg-bg/80 px-6 text-center">
            <p className="text-lg font-semibold text-balance">Acabou</p>
            {nextTitle && !canceled && autoplay ? (
              <p className="text-sm text-muted">Próximo em {count}s · {nextTitle}</p>
            ) : null}
            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                className="tap min-h-11 rounded-lg bg-accent px-4 text-sm font-semibold text-accent-ink"
                onClick={() => {
                  setEnded(false);
                  setCanceled(false);
                  seek(0);
                  void videoRef.current?.play();
                }}
              >
                Assistir de novo
              </button>
              {onNext ? (
                <button
                  type="button"
                  className="tap min-h-11 rounded-lg border border-line bg-surface px-4 text-sm font-semibold"
                  onClick={() => onNext()}
                >
                  Próximo
                </button>
              ) : null}
              {onNext && autoplay && !canceled ? (
                <button type="button" className="min-h-11 px-3 text-sm text-muted" onClick={() => setCanceled(true)}>
                  Cancelar
                </button>
              ) : null}
            </div>
          </div>
        ) : null}

        <div className={cn("absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/80 to-transparent px-3 pt-10 pb-2", ended && "hidden")}>
          <div
            role="slider"
            tabIndex={0}
            aria-label="Posição do vídeo"
            aria-valuemin={0}
            aria-valuemax={Math.round(duration || 0)}
            aria-valuenow={Math.round(time)}
            className="group relative flex h-6 cursor-pointer touch-none items-center"
            onPointerDown={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();
              const ratio = (event.clientX - rect.left) / rect.width;
              seek(ratio * (duration || 0));
              event.currentTarget.setPointerCapture(event.pointerId);
            }}
            onPointerMove={(event) => {
              if (event.buttons !== 1) return;
              const rect = event.currentTarget.getBoundingClientRect();
              const ratio = (event.clientX - rect.left) / rect.width;
              seek(ratio * (duration || 0));
            }}
            onKeyDown={(event) => {
              if (event.key === "ArrowRight") seek(time + 5);
              if (event.key === "ArrowLeft") seek(time - 5);
            }}
          >
            <span className="relative h-1 w-full rounded-full bg-fg/25 group-hover:h-1.5">
              <span className="absolute inset-y-0 left-0 rounded-full bg-accent" style={{ width: `${percent}%` }} />
            </span>
          </div>
          <div className="mt-1 flex items-center gap-1 text-fg">
            <button type="button" className="tap grid size-11 place-items-center" aria-label={playing ? "Pausar" : "Reproduzir"} onClick={toggle}>
              {playing ? <Pause className="size-5 fill-current" /> : <Play className="size-5 fill-current" />}
            </button>
            {onNext ? (
              <button type="button" className="tap grid size-11 place-items-center" aria-label="Próximo" onClick={onNext}>
                <SkipForward className="size-5" />
              </button>
            ) : null}
            <span className="px-1 text-xs tabular-nums text-fg/90">
              {formatClock(time)} / {formatClock(duration)}
            </span>
            <span className="flex-1" />
            <button
              type="button"
              className="tap grid size-11 place-items-center"
              aria-label={muted || volume === 0 ? "Ativar som" : "Silenciar"}
              onClick={() => setMuted((value) => !value)}
            >
              {muted || volume === 0 ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </button>
            <input
              aria-label="Volume"
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={(event) => {
                const next = Number(event.target.value);
                setMuted(false);
                setVolume(next);
              }}
              className="hidden w-20 accent-accent sm:block"
            />
            <label className="sr-only" htmlFor={`rate-${videoKey}`}>
              Velocidade
            </label>
            <select
              id={`rate-${videoKey}`}
              aria-label="Velocidade"
              value={rate}
              onChange={(event) => {
                const next = Number(event.target.value);
                setRate(next);
                if (videoRef.current) videoRef.current.playbackRate = next;
              }}
              className="h-9 rounded-md bg-transparent px-1 text-xs font-semibold"
            >
              {RATES.map((item) => (
                <option key={item} value={item} className="bg-surface text-fg">
                  {item}×
                </option>
              ))}
            </select>
            {sources.length > 1 ? (
              <select
                aria-label="Qualidade"
                value={source?.label ?? ""}
                onChange={(event) => {
                  const next = sources.find((item) => item.label === event.target.value);
                  if (next) changeSource(next);
                }}
                className="h-9 max-w-20 rounded-md bg-transparent px-1 text-xs font-semibold"
              >
                {sources.map((item) => (
                  <option key={item.label} value={item.label} className="bg-surface text-fg">
                    {item.label}
                  </option>
                ))}
              </select>
            ) : null}
            <button type="button" className="tap grid size-11 place-items-center" aria-label="Tela cheia" onClick={() => void toggleFullscreen()}>
              {fullscreen ? <Minimize className="size-5" /> : <Maximize className="size-5" />}
            </button>
          </div>
        </div>
      </div>
      <p className="sr-only">{title}</p>
      <div className={cn("flex items-center justify-between gap-3 px-3 py-2 text-xs text-muted", "max-sm:hidden")}>
        <span>Espaço reproduz · setas pulam 5s · F tela cheia · N próximo</span>
        <button type="button" className="font-medium text-fg" onClick={() => setAutoplay(!autoplay)}>
          {autoplay ? "Autoplay ligado" : "Autoplay desligado"}
        </button>
      </div>
    </div>
  );
}
