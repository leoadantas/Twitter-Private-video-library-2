import { useServerFn } from "@tanstack/react-start";
import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { resolveVideo } from "@/lib/resolve-video";
import { useLibrary } from "@/lib/library";
import { INBOX_ID, SAMPLE_REF } from "@/lib/types";
import { cn } from "@/lib/cn";

export function AddVideoForm({
  playlistId,
  onDone,
  showSample,
}: {
  playlistId?: string;
  onDone?: () => void;
  showSample?: boolean;
}) {
  const resolve = useServerFn(resolveVideo);
  const navigate = useNavigate();
  const playlists = useLibrary((state) => state.playlists);
  const saveTweet = useLibrary((state) => state.saveTweet);
  const createPlaylist = useLibrary((state) => state.createPlaylist);
  const [ref, setRef] = useState("");
  const [folderId, setFolderId] = useState(playlistId || INBOX_ID);
  const [folderName, setFolderName] = useState("");
  const [makingFolder, setMakingFolder] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function save(value: string, target: string) {
    setBusy(true);
    setError(null);
    const result = await resolve({ data: { ref: value } });
    if (!result.ok) {
      setError(result.message);
      setBusy(false);
      return;
    }
    const status = saveTweet(result.tweet, target);
    toast(status === "exists" ? "Esse vídeo já estava na pasta" : "Vídeo salvo");
    setRef("");
    setBusy(false);
    onDone?.();
    await navigate({
      to: "/watch/$videoId",
      params: { videoId: result.tweet.id },
      search: { list: target },
    });
  }

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!busy && ref.trim()) void save(ref, folderId);
      }}
      className="grid gap-3"
    >
      <label className="grid gap-2 text-sm font-medium">
        Link do post
        <input
          value={ref}
          onChange={(event) => setRef(event.target.value)}
          placeholder="https://x.com/alguem/status/…"
          inputMode="url"
          autoComplete="off"
          spellCheck={false}
          className="min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-base font-normal text-fg outline-none placeholder:text-muted"
        />
      </label>
      <div className="grid gap-2 sm:grid-cols-[1fr_auto] sm:items-end">
        <label className="grid gap-2 text-sm font-medium">
          Pasta
          <select
            value={folderId}
            onChange={(event) => setFolderId(event.target.value)}
            className="min-h-11 rounded-lg border border-line bg-bg px-3 text-base font-normal text-fg"
          >
            {playlists.map((playlist) => (
              <option key={playlist.id} value={playlist.id}>
                {playlist.name}
              </option>
            ))}
          </select>
        </label>
        <button
          type="submit"
          disabled={busy || !ref.trim()}
          className="tap min-h-11 rounded-lg bg-accent px-4 font-semibold text-accent-ink disabled:opacity-50"
        >
          {busy ? "Buscando…" : "Salvar"}
        </button>
      </div>
      {makingFolder ? (
        <div className="flex gap-2">
          <input
            value={folderName}
            onChange={(event) => setFolderName(event.target.value)}
            placeholder="Nome da pasta"
            className="min-h-11 min-w-0 flex-1 rounded-lg border border-line bg-bg px-3 text-base"
          />
          <button
            type="button"
            className="tap min-h-11 rounded-lg border border-line px-3 text-sm font-semibold"
            onClick={() => {
              const id = createPlaylist(folderName);
              if (!id) {
                setError("Dá um nome para a pasta.");
                return;
              }
              setFolderId(id);
              setFolderName("");
              setMakingFolder(false);
            }}
          >
            Criar
          </button>
        </div>
      ) : (
        <button
          type="button"
          className="w-fit text-sm font-medium text-accent"
          onClick={() => setMakingFolder(true)}
        >
          Nova pasta
        </button>
      )}
      {error ? <p className="text-sm text-accent">{error}</p> : null}
      {showSample ? (
        <button
          type="button"
          disabled={busy}
          className={cn("w-fit text-sm text-muted underline-offset-4 hover:text-fg hover:underline", busy && "opacity-50")}
          onClick={() => void save(SAMPLE_REF, folderId)}
        >
          Ver um exemplo com um vídeo público
        </button>
      ) : null}
    </form>
  );
}
