import * as Dialog from "@radix-ui/react-dialog";
import { Link, useRouterState } from "@tanstack/react-router";
import { FolderPlus, ListVideo, Menu, Play, Plus, Search, X } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { AddVideoForm } from "@/components/add-video-form";
import { useLibrary } from "@/lib/library";
import { INBOX_ID } from "@/lib/types";
import { cn } from "@/lib/cn";

function typingTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  return Boolean(target.closest("input, textarea, select, [contenteditable='true']"));
}

function bookmarklet(origin: string) {
  const code = `(function(){var m=location.href.match(/status(?:es)?\\/(\\d+)/);if(!m){alert("Abra um post do X primeiro.");return;}window.open(${JSON.stringify(
    origin,
  )}+"/?add="+m[1]);})();`;
  return `javascript:${code}`;
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const hydrated = useLibrary((state) => state.hydrated);
  const playlists = useLibrary((state) => state.playlists);
  const videoCount = useLibrary((state) => Object.keys(state.videos).length);
  const query = useLibrary((state) => state.query);
  const setQuery = useLibrary((state) => state.setQuery);
  const composerOpen = useLibrary((state) => state.composerOpen);
  const closeComposer = useLibrary((state) => state.closeComposer);
  const openComposer = useLibrary((state) => state.openComposer);
  const composerPlaylistId = useLibrary((state) => state.composerPlaylistId);
  const folderOpen = useLibrary((state) => state.folderOpen);
  const setFolderOpen = useLibrary((state) => state.setFolderOpen);
  const createPlaylist = useLibrary((state) => state.createPlaylist);
  const [navOpen, setNavOpen] = useState(false);
  const [folderName, setFolderName] = useState("");
  const [folderError, setFolderError] = useState<string | null>(null);
  const [origin, setOrigin] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const pending = useLibrary.persist.rehydrate();
    void Promise.resolve(pending).finally(() => {
      useLibrary.setState({ hydrated: true });
    });
    setOrigin(window.location.origin);
  }, []);

  useEffect(() => {
    setNavOpen(false);
  }, [pathname]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "/" && !typingTarget(event.target)) {
        event.preventDefault();
        searchRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const nav = (
    <nav className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-3 py-4">
      <NavLink to="/" active={pathname === "/"} icon={<ListVideo className="size-4" />} label="Todos os vídeos" />
      <p className="mt-5 mb-1 flex items-center justify-between px-3 text-xs font-semibold tracking-wide text-muted">
        Pastas
        <button
          type="button"
          className="tap grid size-11 place-items-center rounded-md text-muted hover:bg-raised hover:text-fg"
          aria-label="Nova pasta"
          onClick={() => {
            setFolderError(null);
            setFolderOpen(true);
          }}
        >
          <FolderPlus className="size-4" />
        </button>
      </p>
      {playlists.map((playlist) => (
        <NavLink
          key={playlist.id}
          to="/p/$playlistId"
          params={{ playlistId: playlist.id }}
          active={pathname === `/p/${playlist.id}`}
          icon={<span className="size-1.5 rounded-full bg-accent" />}
          label={playlist.name}
          count={playlist.videoIds.length}
        />
      ))}
    </nav>
  );

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="pointer-events-none fixed inset-x-0 top-0 z-50 h-0.5 bg-accent" />
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-line bg-surface pt-0.5 md:flex">
        <Link to="/" search={{ add: undefined }} className="flex items-center gap-3 px-4 py-5">
          <Wordmark />
        </Link>
        {nav}
        <SidebarFoot origin={origin} />
      </aside>

      {navOpen ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button type="button" aria-label="Fechar menu" className="absolute inset-0 bg-bg/70" onClick={() => setNavOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-72 flex-col border-r border-line bg-surface pt-0.5">
            <div className="flex items-center justify-between px-4 py-4">
              <Wordmark />
              <button type="button" aria-label="Fechar" className="tap grid size-11 place-items-center" onClick={() => setNavOpen(false)}>
                <X className="size-5" />
              </button>
            </div>
            {nav}
            <SidebarFoot origin={origin} />
          </div>
        </div>
      ) : null}

      <div className="min-w-0 md:pl-64">
        <header className="sticky top-0 z-30 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 border-b border-line bg-bg/90 px-3 py-2 backdrop-blur-md md:px-6">
          <div className="flex items-center gap-1">
            <button
              type="button"
              className="tap grid size-11 place-items-center rounded-lg md:hidden"
              aria-label="Abrir menu"
              onClick={() => setNavOpen(true)}
            >
              <Menu className="size-5" />
            </button>
            <Link to="/" search={{ add: undefined }} className="pr-2 font-extrabold md:hidden">
              Depois
            </Link>
          </div>
          {videoCount > 0 ? (
            <label className="relative min-w-0">
              <span className="sr-only">Buscar na biblioteca</span>
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
              <input
                ref={searchRef}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Buscar na biblioteca"
                className="min-h-11 w-full rounded-lg border border-line bg-surface pr-3 pl-9 text-sm outline-none placeholder:text-muted"
              />
            </label>
          ) : (
            <span />
          )}
          <button
            type="button"
            className="tap inline-flex min-h-11 items-center gap-2 rounded-lg bg-accent px-3 font-semibold text-accent-ink"
            onClick={() => openComposer(pathname.startsWith("/p/") ? pathname.split("/")[2] : INBOX_ID)}
          >
            <Plus className="size-4" />
            <span className="hidden sm:inline">Adicionar</span>
          </button>
        </header>
        <main className="mx-auto w-full max-w-7xl px-4 py-6 md:px-6">
          {hydrated ? children : <p className="py-10 text-sm text-muted">Abrindo sua biblioteca…</p>}
        </main>
      </div>

      <Dialog.Root open={composerOpen} onOpenChange={(open) => (open ? openComposer(composerPlaylistId) : closeComposer())}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/70" />
          <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-lg -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 shadow-2xl">
            <Dialog.Title className="text-lg font-bold">Adicionar vídeo</Dialog.Title>
            <Dialog.Description className="mt-1 mb-4 text-sm text-pretty text-muted">
              No X, abra o vídeo, toque em compartilhar e copie o link do post.
            </Dialog.Description>
            <AddVideoForm playlistId={composerPlaylistId} onDone={closeComposer} showSample={videoCount === 0} />
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>

      <Dialog.Root open={folderOpen} onOpenChange={setFolderOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/70" />
          <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 shadow-2xl">
            <Dialog.Title className="text-lg font-bold">Nova pasta</Dialog.Title>
            <Dialog.Description className="mt-1 mb-4 text-sm text-muted">
              Uma fila só com o que você escolher. Ex.: noite, jogos, aulas.
            </Dialog.Description>
            <form
              className="grid gap-3"
              onSubmit={(event) => {
                event.preventDefault();
                const id = createPlaylist(folderName);
                if (!id) {
                  setFolderError("Dá um nome para a pasta.");
                  return;
                }
                setFolderName("");
                setFolderError(null);
                setFolderOpen(false);
              }}
            >
              <input
                value={folderName}
                onChange={(event) => setFolderName(event.target.value)}
                placeholder="Nome da pasta"
                className="min-h-11 rounded-lg border border-line bg-bg px-3"
                autoFocus
              />
              {folderError ? <p className="text-sm text-accent">{folderError}</p> : null}
              <button type="submit" className="tap min-h-11 rounded-lg bg-accent font-semibold text-accent-ink">
                Criar pasta
              </button>
            </form>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}

function Wordmark() {
  return (
    <span className="flex items-center gap-3">
      <span className="grid size-9 place-items-center rounded-lg bg-accent text-accent-ink">
        <Play className="size-4 fill-current" />
      </span>
      <span className="leading-tight">
        <span className="block text-lg font-extrabold tracking-tight">Depois</span>
        <span className="block text-xs text-muted">vídeos do X, no seu tempo</span>
      </span>
    </span>
  );
}

function NavLink({
  to,
  params,
  active,
  icon,
  label,
  count,
}: {
  to: "/" | "/p/$playlistId";
  params?: { playlistId: string };
  active: boolean;
  icon: ReactNode;
  label: string;
  count?: number;
}) {
  if (to === "/") {
    return (
      <Link
        to="/"
        search={{ add: undefined }}
        className={cn(
          "flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium",
          active ? "bg-raised text-fg" : "text-muted hover:bg-raised hover:text-fg",
        )}
      >
        {icon}
        <span className="min-w-0 flex-1 truncate">{label}</span>
      </Link>
    );
  }
  return (
    <Link
      to="/p/$playlistId"
      params={params ?? { playlistId: INBOX_ID }}
      className={cn(
        "flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium",
        active ? "bg-raised text-fg" : "text-muted hover:bg-raised hover:text-fg",
      )}
    >
      {icon}
      <span className="min-w-0 flex-1 truncate">{label}</span>
      {typeof count === "number" ? <span className="text-xs tabular-nums text-muted">{count}</span> : null}
    </Link>
  );
}

function SidebarFoot({ origin }: { origin: string }) {
  return (
    <div className="border-t border-line px-4 py-4 text-xs text-pretty text-muted">
      <p>Fica salvo neste navegador.</p>
      <details className="mt-3 hidden md:block">
        <summary className="cursor-pointer font-medium text-fg">Atalho dentro do x.com</summary>
        <p className="mt-2">
          Arraste o botão para a barra de favoritos. No navegador, abra um vídeo do X e clique nele.
        </p>
        <a
          href="#salvar"
          ref={(node) => {
            if (node && origin) node.href = bookmarklet(origin);
          }}
          onClick={(event) => event.preventDefault()}
          className="mt-2 inline-flex min-h-11 items-center rounded-lg border border-line bg-raised px-3 text-sm font-semibold text-fg"
        >
          Salvar no Depois
        </a>
      </details>
    </div>
  );
}
