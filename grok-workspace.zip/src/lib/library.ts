import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  INBOX_ID,
  type Playlist,
  type ResolvedTweet,
  type SavedVideo,
  type VideoSnapshot,
} from "@/lib/types";

type Persisted = {
  videos: Record<string, SavedVideo>;
  playlists: Playlist[];
  autoplay: boolean;
  volume: number;
};

type Library = Persisted & {
  hydrated: boolean;
  query: string;
  composerOpen: boolean;
  composerPlaylistId: string;
  folderOpen: boolean;
  setQuery: (query: string) => void;
  openComposer: (playlistId?: string) => void;
  closeComposer: () => void;
  setFolderOpen: (open: boolean) => void;
  saveTweet: (tweet: ResolvedTweet, playlistId: string) => "added" | "exists";
  createPlaylist: (name: string) => string | null;
  renamePlaylist: (id: string, name: string) => void;
  deletePlaylist: (id: string) => void;
  toggleMembership: (videoId: string, playlistId: string) => void;
  removeFromPlaylist: (videoId: string, playlistId: string) => void;
  removeFromLibrary: (videoId: string) => VideoSnapshot | null;
  restore: (snapshot: VideoSnapshot) => void;
  setProgress: (id: string, positionSec: number, durationSec: number) => void;
  setCompleted: (id: string, completed: boolean) => void;
  setClipIndex: (id: string, clipIndex: number) => void;
  refreshMeta: (tweet: ResolvedTweet) => void;
  setAutoplay: (autoplay: boolean) => void;
  setVolume: (volume: number) => void;
};

function inbox(): Playlist {
  return { id: INBOX_ID, name: "Assistir depois", videoIds: [], createdAt: 0 };
}

function withInbox(playlists: Playlist[]): Playlist[] {
  if (playlists.some((playlist) => playlist.id === INBOX_ID)) return playlists;
  return [inbox(), ...playlists];
}

function cleanName(name: string): string | null {
  const trimmed = name.trim().replace(/\s+/g, " ");
  if (!trimmed) return null;
  return trimmed.slice(0, 40);
}

function membershipsOf(playlists: Playlist[], videoId: string) {
  return playlists.filter((playlist) => playlist.videoIds.includes(videoId)).map((playlist) => playlist.id);
}

export const useLibrary = create<Library>()(
  persist(
    (set, get) => ({
      videos: {},
      playlists: [inbox()],
      autoplay: true,
      volume: 1,
      hydrated: false,
      query: "",
      composerOpen: false,
      composerPlaylistId: INBOX_ID,
      folderOpen: false,
      setQuery: (query) => set({ query }),
      openComposer: (playlistId) =>
        set({ composerOpen: true, composerPlaylistId: playlistId || INBOX_ID }),
      closeComposer: () => set({ composerOpen: false }),
      setFolderOpen: (folderOpen) => set({ folderOpen }),
      saveTweet: (tweet, playlistId) => {
        const target = get().playlists.some((playlist) => playlist.id === playlistId) ? playlistId : INBOX_ID;
        const existing = get().videos[tweet.id];
        const already = existing ? get().playlists.some((playlist) => playlist.id === target && playlist.videoIds.includes(tweet.id)) : false;
        set((state) => {
          const previous = state.videos[tweet.id];
          const saved: SavedVideo = {
            ...tweet,
            clipIndex: previous?.clipIndex ?? 0,
            addedAt: previous?.addedAt ?? Date.now(),
            positionSec: previous?.positionSec ?? 0,
            completed: previous?.completed ?? false,
          };
          if (saved.clipIndex >= saved.clips.length) saved.clipIndex = 0;
          return {
            videos: { ...state.videos, [tweet.id]: saved },
            playlists: state.playlists.map((playlist) => {
              if (playlist.id !== target || playlist.videoIds.includes(tweet.id)) return playlist;
              return { ...playlist, videoIds: [tweet.id, ...playlist.videoIds] };
            }),
          };
        });
        return already ? "exists" : "added";
      },
      createPlaylist: (name) => {
        const clean = cleanName(name);
        if (!clean) return null;
        const id = `pl_${crypto.randomUUID()}`;
        set((state) => ({
          playlists: [...state.playlists, { id, name: clean, videoIds: [], createdAt: Date.now() }],
        }));
        return id;
      },
      renamePlaylist: (id, name) => {
        const clean = cleanName(name);
        if (!clean) return;
        set((state) => ({
          playlists: state.playlists.map((playlist) => (playlist.id === id ? { ...playlist, name: clean } : playlist)),
        }));
      },
      deletePlaylist: (id) => {
        if (id === INBOX_ID) return;
        set((state) => ({
          playlists: state.playlists.filter((playlist) => playlist.id !== id),
        }));
      },
      toggleMembership: (videoId, playlistId) => {
        if (!get().videos[videoId]) return;
        set((state) => ({
          playlists: state.playlists.map((playlist) => {
            if (playlist.id !== playlistId) return playlist;
            const has = playlist.videoIds.includes(videoId);
            return {
              ...playlist,
              videoIds: has ? playlist.videoIds.filter((item) => item !== videoId) : [videoId, ...playlist.videoIds],
            };
          }),
        }));
      },
      removeFromPlaylist: (videoId, playlistId) => {
        set((state) => ({
          playlists: state.playlists.map((playlist) =>
            playlist.id === playlistId
              ? { ...playlist, videoIds: playlist.videoIds.filter((item) => item !== videoId) }
              : playlist,
          ),
        }));
      },
      removeFromLibrary: (videoId) => {
        const video = get().videos[videoId];
        if (!video) return null;
        const snapshot: VideoSnapshot = { video, memberships: membershipsOf(get().playlists, videoId) };
        set((state) => {
          const videos = { ...state.videos };
          delete videos[videoId];
          return {
            videos,
            playlists: state.playlists.map((playlist) => ({
              ...playlist,
              videoIds: playlist.videoIds.filter((item) => item !== videoId),
            })),
          };
        });
        return snapshot;
      },
      restore: (snapshot) => {
        set((state) => ({
          videos: { ...state.videos, [snapshot.video.id]: snapshot.video },
          playlists: state.playlists.map((playlist) => {
            if (!snapshot.memberships.includes(playlist.id) || playlist.videoIds.includes(snapshot.video.id)) {
              return playlist;
            }
            return { ...playlist, videoIds: [snapshot.video.id, ...playlist.videoIds] };
          }),
        }));
      },
      setProgress: (id, positionSec, durationSec) => {
        set((state) => {
          const video = state.videos[id];
          if (!video) return state;
          const completed = video.completed || (durationSec > 0 && positionSec / durationSec >= 0.9);
          return {
            videos: {
              ...state.videos,
              [id]: { ...video, positionSec, completed },
            },
          };
        });
      },
      setCompleted: (id, completed) => {
        set((state) => {
          const video = state.videos[id];
          if (!video) return state;
          return {
            videos: {
              ...state.videos,
              [id]: { ...video, completed, positionSec: completed ? video.positionSec : 0 },
            },
          };
        });
      },
      setClipIndex: (id, clipIndex) => {
        set((state) => {
          const video = state.videos[id];
          if (!video || !video.clips[clipIndex]) return state;
          return {
            videos: {
              ...state.videos,
              [id]: { ...video, clipIndex, positionSec: 0 },
            },
          };
        });
      },
      refreshMeta: (tweet) => {
        set((state) => {
          const video = state.videos[tweet.id];
          if (!video) return state;
          const clipIndex = video.clipIndex < tweet.clips.length ? video.clipIndex : 0;
          return {
            videos: {
              ...state.videos,
              [tweet.id]: { ...video, ...tweet, clipIndex },
            },
          };
        });
      },
      setAutoplay: (autoplay) => set({ autoplay }),
      setVolume: (volume) => set({ volume: Math.min(1, Math.max(0, volume)) }),
    }),
    {
      name: "depois-library-v1",
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
      partialize: (state): Persisted => ({
        videos: state.videos,
        playlists: state.playlists,
        autoplay: state.autoplay,
        volume: state.volume,
      }),
      merge: (persisted, current) => {
        const data = (persisted ?? {}) as Partial<Persisted>;
        const playlists = Array.isArray(data.playlists) ? data.playlists.filter((playlist) => playlist && typeof playlist.id === "string") : [];
        const videos: Record<string, SavedVideo> = {};
        if (data.videos && typeof data.videos === "object") {
          for (const video of Object.values(data.videos)) {
            if (video && typeof video.id === "string" && Array.isArray(video.clips) && video.clips.length > 0) {
              videos[video.id] = video;
            }
          }
        }
        return {
          ...current,
          videos,
          playlists: withInbox(playlists).map((playlist) => ({
            ...playlist,
            videoIds: (playlist.videoIds ?? []).filter((id) => typeof id === "string" && videos[id]),
          })),
          autoplay: typeof data.autoplay === "boolean" ? data.autoplay : true,
          volume: typeof data.volume === "number" ? data.volume : 1,
          hydrated: true,
        };
      },
    },
  ),
);

export function videosIn(playlist: Playlist | undefined, videos: Record<string, SavedVideo>): SavedVideo[] {
  if (!playlist) return [];
  return playlist.videoIds.map((id) => videos[id]).filter((video): video is SavedVideo => Boolean(video));
}

export function allVideos(videos: Record<string, SavedVideo>): SavedVideo[] {
  return Object.values(videos).sort((a, b) => b.addedAt - a.addedAt);
}
