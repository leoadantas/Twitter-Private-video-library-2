import { createServerFn } from "@tanstack/react-start";
import type { Clip, ResolveResult, Source } from "@/lib/types";
import { extractStatusId } from "@/lib/x-url";

type FxFormat = { url?: string; bitrate?: number | null; container?: string };
type FxMedia = {
  url?: string;
  thumbnail_url?: string;
  duration?: number;
  type?: string;
  formats?: FxFormat[];
};

function isMp4(url: string, container?: string) {
  if (container === "m3u8" || url.includes(".m3u8")) return false;
  return container === "mp4" || url.includes(".mp4");
}

function labelFor(url: string, bitrate: number): string {
  const size = url.match(/\/(\d+)x(\d+)\//);
  if (size) return `${Number(size[2])}p`;
  if (bitrate <= 300_000) return "270p";
  if (bitrate <= 900_000) return "360p";
  if (bitrate <= 2_500_000) return "720p";
  if (bitrate <= 8_000_000) return "1080p";
  return "4K";
}

function dedupeSources(list: Source[]): Source[] {
  const map = new Map<string, Source>();
  for (const source of list) {
    const prev = map.get(source.label);
    if (!prev || source.bitrate > prev.bitrate) map.set(source.label, source);
  }
  return [...map.values()].sort((a, b) => a.bitrate - b.bitrate);
}

function clipsFrom(media: { all?: FxMedia[] } | null | undefined): Clip[] {
  const clips: Clip[] = [];
  for (const item of media?.all ?? []) {
    const formats = (item.formats ?? []).filter((format) => format.url && isMp4(format.url, format.container));
    if (!formats.length && item.url && isMp4(item.url)) {
      formats.push({ url: item.url, bitrate: 0, container: "mp4" });
    }
    if (!formats.length) continue;
    const sources = dedupeSources(
      formats.map((format) => ({
        url: format.url as string,
        bitrate: format.bitrate ?? 0,
        label: labelFor(format.url as string, format.bitrate ?? 0),
      })),
    );
    clips.push({
      thumbnailUrl: item.thumbnail_url || "",
      durationSec: item.duration || 0,
      sources,
    });
    if (clips.length >= 4) break;
  }
  return clips;
}

export const resolveVideo = createServerFn({ method: "POST" })
  .validator((input: { ref: string }) => {
    const ref = typeof input?.ref === "string" ? input.ref.trim() : "";
    if (!ref || ref.length > 500) {
      return { ref: "" };
    }
    return { ref };
  })
  .handler(async ({ data }): Promise<ResolveResult> => {
    const id = extractStatusId(data.ref);
    if (!id) {
      return { ok: false, message: "Isso não parece um link de post do X." };
    }

    let response: Response;
    try {
      response = await fetch(`https://api.fxtwitter.com/status/${id}`, {
        signal: AbortSignal.timeout(12_000),
        headers: { accept: "application/json" },
      });
    } catch {
      return { ok: false, message: "Sem conexão com o X agora. Tenta de novo." };
    }

    let payload: {
      code?: number;
      tweet?: {
        url?: string;
        text?: string;
        author?: { name?: string; screen_name?: string; avatar_url?: string };
        media?: { all?: FxMedia[] } | null;
      } | null;
    };
    try {
      payload = (await response.json()) as typeof payload;
    } catch {
      return { ok: false, message: "O X não devolveu esse post. Tenta de novo." };
    }

    if (!response.ok || payload.code === 404 || !payload.tweet) {
      return { ok: false, message: "Não achei esse post. Ele pode ser privado ou ter sido apagado." };
    }

    const tweet = payload.tweet;
    const clips = clipsFrom(tweet.media);
    if (!clips.length) {
      return {
        ok: false,
        message: "Esse post não tem vídeo. Abre um vídeo no X, toca em compartilhar e copia o link.",
      };
    }

    const handle = tweet.author?.screen_name || "x";
    return {
      ok: true,
      tweet: {
        id,
        url: tweet.url || `https://x.com/${handle}/status/${id}`,
        text: (tweet.text || "").replace(/\s+/g, " ").trim().slice(0, 2000),
        authorName: tweet.author?.name || handle,
        authorHandle: handle,
        avatarUrl: tweet.author?.avatar_url || "",
        clips,
      },
    };
  });
