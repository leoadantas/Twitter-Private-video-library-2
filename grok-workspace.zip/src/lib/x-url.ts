const HOSTS = new Set([
  "x.com",
  "twitter.com",
  "mobile.x.com",
  "mobile.twitter.com",
  "fxtwitter.com",
  "vxtwitter.com",
  "fixupx.com",
]);

export function extractStatusId(input: string): string | null {
  const trimmed = input.trim();
  if (/^\d{1,22}$/.test(trimmed)) return trimmed;
  try {
    const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const url = new URL(withProto);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (!HOSTS.has(host)) return null;
    const match = url.pathname.match(/\/status(?:es)?\/(\d{1,22})/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}

export function videoTitle(video: { text: string; authorHandle: string }): string {
  const text = video.text.replace(/\s+/g, " ").trim();
  return text || `Vídeo de @${video.authorHandle}`;
}

export function formatClock(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) sec = 0;
  const total = Math.floor(sec);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatLoose(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  if (s < 60) return `${s} s`;
  const minutes = Math.round(s / 60);
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h} h ${m} min` : `${h} h`;
}

export function primaryClip<T extends { clips: { durationSec: number; thumbnailUrl: string }[]; clipIndex?: number }>(
  video: T,
) {
  const index = video.clipIndex ?? 0;
  return video.clips[index] ?? video.clips[0];
}

export function matchesQuery(video: { text: string; authorName: string; authorHandle: string }, query: string) {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;
  return (
    video.text.toLowerCase().includes(needle) ||
    video.authorName.toLowerCase().includes(needle) ||
    video.authorHandle.toLowerCase().includes(needle)
  );
}
