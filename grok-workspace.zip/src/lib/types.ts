export type Source = {
  url: string;
  bitrate: number;
  label: string;
};

export type Clip = {
  thumbnailUrl: string;
  durationSec: number;
  sources: Source[];
};

export type ResolvedTweet = {
  id: string;
  url: string;
  text: string;
  authorName: string;
  authorHandle: string;
  avatarUrl: string;
  clips: Clip[];
};

export type SavedVideo = ResolvedTweet & {
  clipIndex: number;
  addedAt: number;
  positionSec: number;
  completed: boolean;
};

export type Playlist = {
  id: string;
  name: string;
  videoIds: string[];
  createdAt: number;
};

export type VideoSnapshot = {
  video: SavedVideo;
  memberships: string[];
};

export type ResolveResult =
  | { ok: true; tweet: ResolvedTweet }
  | { ok: false; message: string };

export const INBOX_ID = "inbox";

export const SAMPLE_REF = "https://x.com/NASAAdmin/status/2114425731832775042";
